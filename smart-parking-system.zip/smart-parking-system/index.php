<?php
require_once('includes/db_connect.php');
// Fetch Pricing from settings
$rate_res = $conn->query("SELECT setting_value FROM system_settings WHERE setting_key = 'price_per_hour'");
$rate = $rate_res->fetch_assoc()['setting_value'] ?? '50';

// Fetch availability counts
$total_slots = $conn->query("SELECT COUNT(*) as total FROM parking_slots")->fetch_assoc()['total'];
$available_slots = $conn->query("SELECT COUNT(*) as avail FROM parking_slots WHERE status = 'available'")->fetch_assoc()['avail'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Park | Efficient Parking Solutions</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root { 
            --primary: #3498db; 
            --dark: #2c3e50; 
            --accent: #1abc9c; 
            --light: #ffffff;
            --bg: #f4f7f6;
        }

        body { 
            font-family: 'Poppins', sans-serif; 
            margin: 0; 
            background: var(--bg); 
            color: var(--dark); 
            scroll-behavior: smooth;
        }

        /* Header Navigation */
        header {
            background: var(--light);
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1100px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-links {
            display: flex;
            gap: 25px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            transition: 0.3s;
            font-size: 0.95rem;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .admin-link {
            background: #f1f2f6;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem !important;
            border: 1px solid #dfe4ea;
        }

        .admin-link:hover {
            background: var(--dark) !important;
            color: white !important;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(44, 62, 80, 0.8), rgba(44, 62, 80, 0.8)), 
                        url('https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&q=80&w=1600') no-repeat center/cover;
            color: white;
            padding: 120px 20px;
            text-align: center;
        }

        .hero h1 { font-size: 3rem; margin-bottom: 10px; }
        .hero p { font-size: 1.2rem; opacity: 0.9; }

        .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        
        /* Stats Grid */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: -60px;
        }
        
        .stat-card {
            background: white;
            padding: 40px 20px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.08);
            text-align: center;
            transition: 0.3s;
        }
        
        .stat-card:hover { transform: translateY(-10px); }
        .stat-card h3 { margin: 0; font-size: 3rem; color: var(--primary); }
        .stat-card p { color: #7f8c8d; font-weight: 500; margin-top: 10px; }
        
        /* Elements */
        .pricing-banner {
            background: var(--accent);
            color: white;
            padding: 12px 30px;
            border-radius: 50px;
            display: inline-block;
            margin: 20px 0;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(26, 188, 156, 0.3);
        }

        .btn-main {
            background: var(--primary);
            color: white;
            padding: 16px 45px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            display: inline-block;
            margin-top: 30px;
            transition: 0.3s;
            box-shadow: 0 8px 20px rgba(52, 152, 219, 0.4);
        }

        .btn-main:hover {
            transform: scale(1.05);
            box-shadow: 0 12px 25px rgba(52, 152, 219, 0.5);
        }

        footer {
            margin-top: 100px;
            padding: 40px;
            text-align: center;
            background: var(--dark);
            color: #bdc3c7;
        }
    </style>
</head>
<body>

<header>
    <div class="nav-container">
        <a href="index.php" class="logo">
            <span>🚗 Smart Park</span>
        </a>
        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="bookings.php">My Bookings</a>
            <a href="login.php">Login</a>
            <a href="admin/index.php" class="admin-link">Admin Portal</a>
        </nav>
    </div>
</header>

<div class="hero">
    <h1>Smart Parking Made Simple</h1>
    <p>Find, Book, and Pay for your parking slot in seconds.</p>
    <div class="pricing-banner">Current Rate: Ksh <?php echo $rate; ?> / Hour</div>
    <br>
    <a href="login.php" class="btn-main">Start Booking Now</a>
</div>

<div class="container">
    <div class="stats-container">
        <div class="stat-card">
            <h3><?php echo $available_slots; ?></h3>
            <p>Slots Available Now</p>
        </div>
        <div class="stat-card">
            <h3>100%</h3>
            <p>Secure Payments</p>
        </div>
        <div class="stat-card">
            <h3>QR</h3>
            <p>Instant Digital Tickets</p>
        </div>
    </div>

    <section style="margin-top: 100px; text-align: center; max-width: 700px; margin-left: auto; margin-right: auto;">
        <h2 style="font-size: 2.2rem; margin-bottom: 15px;">Why Choose Smart Park?</h2>
        <p style="color: #7f8c8d; line-height: 1.8;">
            Tired of circling for hours? Our automated system lets you reserve a spot before you even arrive. 
            Integrated with M-Pesa for seamless transactions and QR technology for ticketless entry.
        </p>
    </section>
</div>

<footer>
    <p>&copy; 2026 Smart Parking System | Developed for MKU Solutions</p>
</footer>

</body>
</html>