-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2026 at 11:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_parking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `slot_id` int(11) DEFAULT NULL,
  `reg_number` varchar(20) DEFAULT NULL,
  `county` varchar(50) DEFAULT 'Nairobi',
  `payment_method` varchar(20) DEFAULT 'M-Pesa',
  `reference_no` varchar(50) DEFAULT NULL,
  `status` enum('active','completed','cancelled','pending') DEFAULT 'pending',
  `booking_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `expiry_time` datetime DEFAULT NULL,
  `qr_code_data` varchar(255) DEFAULT NULL,
  `booking_status` enum('active','completed','cancelled','pending') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `slot_id`, `reg_number`, `county`, `payment_method`, `reference_no`, `status`, `booking_time`, `expiry_time`, `qr_code_data`, `booking_status`) VALUES
(1, 6, 2, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 09:46:24', '2026-02-19 08:46:24', 'PK-6-1771407984', 'active'),
(2, 9, 3, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 12:47:05', '2026-02-18 16:47:05', 'PK-9-1771418825', 'cancelled'),
(3, 9, 4, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 18:51:22', '2026-02-18 22:51:22', 'PK-69960A2AAA064-9', 'cancelled'),
(4, 9, 6, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 18:56:18', '2026-02-19 04:56:18', 'PK-69960B523D9B1-9', 'cancelled'),
(5, 9, 7, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 19:02:09', '2026-02-19 02:02:09', 'PK-9-1771441329', 'cancelled'),
(6, 9, 7, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 19:12:11', '2026-02-18 23:12:11', 'PK-69960F0B59806-9', 'cancelled'),
(7, 9, 7, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-02-18 19:22:02', '2026-02-19 03:22:02', 'PK-9-1771442522', 'cancelled'),
(8, 9, 4, NULL, 'Nairobi', 'M-Pesa', NULL, 'active', '2026-03-08 08:00:33', '2026-03-08 13:00:33', 'PK-9-1772956833', 'cancelled'),
(9, 9, 6, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'active', '2026-03-08 08:05:38', '2026-03-08 15:05:38', 'PK-KAA 124-1772957138', 'cancelled'),
(10, 9, 4, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:36:17', '2026-03-08 13:36:17', 'PK-KAA 124-1772958977', 'pending'),
(11, 9, 4, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:37:54', '2026-03-08 13:37:54', NULL, 'pending'),
(12, 9, 3, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:38:15', '2026-03-08 13:38:15', NULL, 'pending'),
(13, 9, 4, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:38:24', '2026-03-08 13:38:24', NULL, 'pending'),
(14, 9, 4, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:40:02', '2026-03-08 13:40:02', NULL, 'pending'),
(15, 9, 4, 'KAA 124', 'Nairobi', 'M-Pesa', NULL, 'cancelled', '2026-03-08 08:40:19', '2026-03-08 13:40:19', 'PK-KAA 124-1772959219', 'pending'),
(16, 9, 7, 'KUX 124', 'Nairobi', 'M-Pesa', 'RXTU123', 'active', '2026-03-08 09:01:26', '2026-03-08 21:01:26', NULL, 'pending'),
(17, 9, 7, 'KIL525', 'Nairobi', 'Bank', 'uyit-ttr0', 'active', '2026-03-08 09:55:20', '2026-03-08 13:55:20', NULL, 'pending'),
(18, 9, 12, 'KDL454', 'Nairobi', 'Bank', 'uyit-ttr0', 'active', '2026-03-08 10:03:06', '2026-03-08 14:03:06', NULL, 'pending'),
(19, 9, 13, 'KCS546', 'Nairobi', 'Bank', 'RXTU1234', 'active', '2026-03-08 10:11:14', '2026-03-08 18:11:14', NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `is_read`, `created_at`) VALUES
(1, 6, 'verified: Your payment of Ksh 1000.20 for Slot slot b has been approved. Enjoy your parking!', 0, '2026-02-18 11:50:47'),
(2, 9, 'verified: Your payment of Ksh 50.01 for Slot slot i has been approved. Enjoy your parking!', 1, '2026-02-18 12:49:18'),
(3, 9, 'verified: Your payment of Ksh 50.01 for Slot slot i has been approved. Enjoy your parking!', 1, '2026-02-18 12:58:23'),
(4, 9, 'verified: Your payment of Ksh 50.01 for Slot slot i has been approved. Enjoy your parking!', 1, '2026-02-18 17:39:38'),
(5, 9, 'verified: Your payment of Ksh 50.01 for Slot slot i has been approved. Enjoy your parking!', 1, '2026-02-18 18:50:45'),
(6, 9, 'verified: Your payment of Ksh 250.05 for Slot R has been approved. Enjoy your parking!', 1, '2026-02-18 19:22:41'),
(7, 9, 'verified: Your payment of Ksh 100.02 for Slot JKIU has been approved. Enjoy your parking!', 1, '2026-03-08 08:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `parking_slots`
--

CREATE TABLE `parking_slots` (
  `id` int(11) NOT NULL,
  `slot_number` varchar(10) NOT NULL,
  `status` enum('available','booked') DEFAULT 'available',
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parking_slots`
--

INSERT INTO `parking_slots` (`id`, `slot_number`, `status`, `last_updated`) VALUES
(1, 'slot a', 'available', '2026-03-08 10:10:19'),
(2, 'slot b', 'available', '2026-03-08 10:10:21'),
(3, 'slot i', 'available', '2026-03-08 09:23:07'),
(4, 'JKIU', 'available', '2026-03-08 08:12:44'),
(6, 'JKIUR', 'available', '2026-03-08 08:12:48'),
(7, 'R', '', '2026-03-08 10:01:44'),
(8, 'Slot 1', 'available', '2026-03-08 09:20:45'),
(9, 'Slot 2', 'available', '2026-03-08 09:20:48'),
(10, 'Slot 3', 'available', '2026-03-08 09:21:01'),
(11, 'Slot 4', 'available', '2026-03-08 09:21:07'),
(12, 'left123', '', '2026-03-08 10:03:23'),
(13, 'zone65', '', '2026-03-08 10:11:30');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('M-Pesa','Credit Card','Cash') DEFAULT 'M-Pesa',
  `transaction_reference` varchar(100) DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') DEFAULT 'pending',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `booking_id`, `amount`, `payment_method`, `transaction_reference`, `payment_status`, `payment_date`) VALUES
(14, 17, 50.01, '', NULL, '', '2026-03-08 09:55:20'),
(15, 18, 50.01, '', NULL, '', '2026-03-08 10:03:06'),
(16, 19, 250.05, '', NULL, '', '2026-03-08 10:11:14');

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `log_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_logs`
--

INSERT INTO `system_logs` (`id`, `action`, `user_id`, `log_time`, `details`) VALUES
(1, 'Login', 6, '2026-02-18 09:26:35', 'User logged in successfully'),
(2, 'New Booking', 6, '2026-02-18 09:46:27', 'User ID 6 booked Slot ID 2 for 20 hours (Ksh 1000.2)'),
(3, 'Payment Verified', 9, '2026-02-18 11:50:48', 'Approved Payment ID: 1'),
(4, 'Login', 9, '2026-02-18 12:46:41', 'User logged in successfully'),
(5, 'Payment Verified', 9, '2026-02-18 12:49:18', 'Approved Payment ID: 2'),
(6, 'Login', 9, '2026-02-18 12:49:58', 'User logged in successfully'),
(7, 'Payment Verified', 9, '2026-02-18 12:58:23', 'Approved Payment ID: 2'),
(8, 'Login', 9, '2026-02-18 13:21:59', 'User logged in successfully'),
(9, 'Payment Verified', 9, '2026-02-18 17:39:38', 'Approved Payment ID: 2'),
(10, 'Payment Verified', 9, '2026-02-18 18:50:45', 'Approved Payment ID: 2'),
(11, 'New Booking', 9, '2026-02-18 18:51:22', 'User booked Slot ID: 4. Booking ID: 3'),
(12, 'New Booking', 9, '2026-02-18 18:56:18', 'Booked slot 6'),
(13, 'Cancellation', 9, '2026-02-18 19:10:34', 'User ID 9 cancelled booking #5. Slot #7 is now free.'),
(14, 'Booking Updated', 9, '2026-02-18 19:12:00', 'User changed booking #4 from Slot #6 to Slot #6'),
(15, 'New Booking', 9, '2026-02-18 19:12:12', 'User created booking #6 for Slot #7'),
(16, 'Cancellation', 9, '2026-02-18 19:12:47', 'User ID 9 cancelled booking #6. Slot #7 is now free.'),
(17, 'Cancellation', 9, '2026-02-18 19:18:05', 'User ID 9 cancelled booking #2. Slot #3 is now free.'),
(18, 'Cancellation', 9, '2026-02-18 19:21:44', 'User ID 9 cancelled booking #4. Slot #6 is now free.'),
(19, 'Cancellation', 9, '2026-02-18 19:21:50', 'User ID 9 cancelled booking #3. Slot #4 is now free.'),
(20, 'Payment Verified', 9, '2026-02-18 19:22:41', 'Approved Payment ID: 4'),
(21, 'Login', 9, '2026-03-08 07:56:36', 'User logged in successfully'),
(22, 'New Booking', 9, '2026-03-08 08:05:38', 'Vehicle KAA 124 booked Slot ID 6'),
(23, 'Cancellation', 9, '2026-03-08 08:12:45', 'User ID 9 cancelled booking #8. Slot #4 is now free.'),
(24, 'Cancellation', 9, '2026-03-08 08:12:48', 'User ID 9 cancelled booking #9. Slot #6 is now free.'),
(25, 'Cancellation', 9, '2026-03-08 08:12:52', 'User ID 9 cancelled booking #7. Slot #7 is now free.'),
(26, 'Login', 9, '2026-03-08 08:34:35', 'User logged in successfully'),
(27, 'Approval Requested', 9, '2026-03-08 08:36:17', 'Vehicle KAA 124 requested Slot ID 4'),
(28, 'Payment Verified', 9, '2026-03-08 08:55:19', 'Approved Payment ID: 12'),
(29, 'Login', 9, '2026-03-08 09:00:25', 'User logged in successfully'),
(30, 'Login', 9, '2026-03-08 09:05:36', 'User logged in successfully'),
(31, 'Login', 9, '2026-03-08 09:14:06', 'User logged in successfully'),
(32, 'Login', 9, '2026-03-08 09:15:26', 'User logged in successfully'),
(33, 'Login', 9, '2026-03-08 09:54:46', 'User logged in successfully'),
(34, 'Login', 9, '2026-03-08 10:02:38', 'User logged in successfully'),
(35, 'Login', 9, '2026-03-08 10:10:39', 'User logged in successfully');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(50) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'price_per_hour', '50.01', '2026-02-18 08:18:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `phone` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `role`, `phone`, `created_at`) VALUES
(6, 'john', 'john@gmail.com', '$2y$10$BgmLqjjAN7BpDpMw47ljduO4kdxtY7PrB6lS/r2UXjGePxrQnhPa.', 'user', '0798458272', '2026-02-18 09:26:27'),
(9, 'System Admin', 'admin@gmail.com', '$2y$10$RQ3MYizvrCpE2SK.eza1yOpd0VJNVrUzdcWZdbYaWOa720RLOvJTe', 'admin', '0700000000', '2026-02-18 11:48:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `slot_id` (`slot_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `parking_slots`
--
ALTER TABLE `parking_slots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slot_number` (`slot_number`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_reference` (`transaction_reference`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `parking_slots`
--
ALTER TABLE `parking_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`slot_id`) REFERENCES `parking_slots` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
