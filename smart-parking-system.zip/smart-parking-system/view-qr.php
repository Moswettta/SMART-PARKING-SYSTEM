<?php
session_start();
require_once('includes/db_connect.php');

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$booking_id = mysqli_real_escape_string($conn, $_GET['id']);
$user_id = $_SESSION['user_id'];

// Fetch booking details
$sql = "SELECT b.*, s.slot_number, u.full_name 
        FROM bookings b 
        JOIN parking_slots s ON b.slot_id = s.id 
        JOIN users u ON b.user_id = u.id 
        WHERE b.id = '$booking_id' AND b.user_id = '$user_id'";

$res = $conn->query($sql);
if ($res->num_rows == 0) {
    header("Location: dashboard.php");
    exit();
}

$data = $res->fetch_assoc();

// Prepare QR Link (Google Charts API)
$qr_content = $data['qr_code_data'];
$qr_url = "https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=" . urlencode($qr_content) . "&choe=UTF-8";

include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="main-content" style="margin-left: 250px; padding: 40px; background-color: #f4f7f6; min-height: 100vh; display: flex; flex-direction: column; align-items: center;">
    
    <div style="background: white; width: 100%; max-width: 450px; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); overflow: hidden; text-align: center;">
        
        <div style="background: #3498db; padding: 25px; color: white;">
            <h2 style="margin: 0; font-size: 1.5rem;">Parking Pass</h2>
            <p style="margin: 5px 0 0; opacity: 0.8; font-size: 0.9rem;">Show this at the entrance</p>
        </div>

        <div style="padding: 30px; background: #fff;">
            <div style="border: 2px dashed #e2e8f0; padding: 15px; border-radius: 15px; display: inline-block;">
                <img src="<?php echo $qr_url; ?>" alt="Booking QR Code" style="display: block;">
            </div>
            <p style="margin-top: 15px; font-family: monospace; color: #64748b; font-weight: bold;">
                <?php echo $data['qr_code_data']; ?>
            </p>
        </div>

        <div style="padding: 0 30px 30px; text-align: left;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; border-top: 1px solid #f1f5f9; padding-top: 25px;">
                <div>
                    <label style="display: block; font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Slot Number</label>
                    <span style="font-size: 1.2rem; font-weight: 800; color: #2c3e50;">Slot <?php echo $data['slot_number']; ?></span>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Rate</label>
                    <span style="font-size: 1.2rem; font-weight: 800; color: #2ecc71;">Ksh 50/hr</span>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Reserved For</label>
                    <span style="font-size: 0.9rem; font-weight: 600; color: #2c3e50;"><?php echo $data['full_name']; ?></span>
                </div>
                <div>
                    <label style="display: block; font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Expires At</label>
                    <span style="font-size: 0.9rem; font-weight: 600; color: #e74c3c;"><?php echo date('h:i A', strtotime($data['expiry_time'])); ?></span>
                </div>
            </div>

            <button onclick="window.print()" style="width: 100%; margin-top: 30px; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; padding: 12px; border-radius: 10px; font-weight: 700; cursor: pointer; transition: 0.3s;">
                🖨️ Print or Save as PDF
            </button>
            
            <a href="dashboard.php" style="display: block; text-align: center; margin-top: 15px; color: #3498db; text-decoration: none; font-weight: 600; font-size: 0.9rem;">
                Return to Dashboard
            </a>
        </div>
    </div>

    <div style="margin-top: 30px; color: #94a3b8; font-size: 0.85rem; max-width: 400px; text-align: center;">
        <p>Please arrive within 15 minutes of your booking time. Your slot will be released if not occupied.</p>
    </div>
</div>

<?php include('includes/footer.php'); ?>