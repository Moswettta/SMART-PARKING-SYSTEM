<?php
require_once('includes/db_connect.php');
require_once('includes/functions.php');
session_start();

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 2. Mark all as read when page is opened
$conn->query("UPDATE notifications SET is_read = 1 WHERE user_id = '$user_id'");

include('includes/header.php');
?>

<style>
    .notif-wrapper {
        display: flex;
        background: #f1f5f9;
        min-height: 100vh;
    }
    .main-content {
        margin-left: 260px;
        padding: 40px;
        width: calc(100% - 260px);
    }
    .notif-list {
        max-width: 800px;
        margin: 0 auto;
    }
    .notif-item {
        background: white;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 15px;
        display: flex;
        gap: 20px;
        align-items: flex-start;
        box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        border-left: 5px solid #cbd5e1;
        transition: 0.2s;
    }
    /* Status-based border colors */
    .notif-item.approved { border-left-color: #22c55e; background: #f0fdf4; }
    .notif-item.payment { border-left-color: #eab308; background: #fefce8; }
    .notif-item.deleted { border-left-color: #ef4444; background: #fef2f2; }

    .notif-icon {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        flex-shrink: 0;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    .notif-content p { margin: 0; color: #334155; font-size: 0.95rem; line-height: 1.5; }
    .notif-time {
        font-size: 0.75rem;
        color: #94a3b8;
        margin-top: 10px;
        display: block;
    }
    .empty-state {
        text-align: center;
        padding: 100px 0;
        color: #94a3b8;
    }
    .badge-text {
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 5px;
        display: block;
    }
</style>

<div class="notif-wrapper">
    <?php include('includes/sidebar.php'); ?>

    <main class="main-content">
        <div style="max-width: 800px; margin: 0 auto 30px;">
            <h1 style="margin:0; color: #0f172a;">Notifications</h1>
            <p style="color: #64748b;">Updates on your International Hotel parking status.</p>
        </div>

        <div class="notif-list">
            <?php
            // Pulling data based on your specific notification table structure
            $sql = "SELECT * FROM notifications WHERE user_id = '$user_id' ORDER BY created_at DESC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $msg = $row['message'];
                    $type_class = '';
                    $icon = '🔔';
                    $label = 'Update';
                    $label_color = '#64748b';

                    // Logic to detect Approved, Payment, or Deleted/Expired
                    if (stripos($msg, 'approved') !== false || stripos($msg, 'verified') !== false) {
                        $type_class = 'approved';
                        $icon = '✅';
                        $label = 'Approved';
                        $label_color = '#16a34a';
                    } elseif (stripos($msg, 'payment') !== false || stripos($msg, 'Ksh') !== false) {
                        $type_class = 'payment';
                        $icon = '💰';
                        $label = 'Payment';
                        $label_color = '#a16207';
                    } elseif (stripos($msg, 'deleted') !== false || stripos($msg, 'cancelled') !== false || stripos($msg, 'expired') !== false) {
                        $type_class = 'deleted';
                        $icon = '🗑️';
                        $label = 'Removed';
                        $label_color = '#dc2626';
                    }
                    ?>
                    <div class="notif-item <?php echo $type_class; ?>">
                        <div class="notif-icon">
                            <?php echo $icon; ?>
                        </div>
                        <div class="notif-content">
                            <span class="badge-text" style="color: <?php echo $label_color; ?>;">
                                <?php echo $label; ?>
                            </span>
                            <p><?php echo htmlspecialchars($msg); ?></p>
                            <span class="notif-time">
                                📅 <?php echo date('D, d M Y - h:i A', strtotime($row['created_at'])); ?>
                            </span>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="empty-state">
                        <div style="font-size: 3rem; margin-bottom: 20px;">📭</div>
                        <h3>No notifications yet</h3>
                        <p>We’ll notify you here about your parking sessions and payments.</p>
                      </div>';
            }
            ?>
        </div>
    </main>
</div>

<?php include('includes/footer.php'); ?>