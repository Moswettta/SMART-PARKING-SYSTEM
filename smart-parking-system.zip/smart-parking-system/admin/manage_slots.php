<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

$message = "";
$msg_type = "";

// --- 1. CREATE: Add New Slot ---
if (isset($_POST['add_slot'])) {
    // FIXED: Changed 'mysqli_real_escape_result' to 'mysqli_real_escape_string'
    $slot_name = mysqli_real_escape_string($conn, $_POST['slot_number']);
    
    $check = $conn->query("SELECT id FROM parking_slots WHERE slot_number = '$slot_name'");
    if ($check->num_rows > 0) {
        $message = "Error: Slot name '$slot_name' already exists!";
        $msg_type = "error";
    } else {
        $conn->query("INSERT INTO parking_slots (slot_number, status) VALUES ('$slot_name', 'available')");
        $message = "New slot created successfully.";
        $msg_type = "success";
    }
}

// --- 2. UPDATE: Toggle Status ---
if (isset($_GET['toggle_id'])) {
    $id = intval($_GET['toggle_id']);
    $current = mysqli_real_escape_string($conn, $_GET['current']);
    $new_status = ($current == 'available') ? 'booked' : 'available';
    $conn->query("UPDATE parking_slots SET status = '$new_status' WHERE id = $id");
    header("Location: manage_slots.php?msg=updated");
    exit();
}

// --- 3. DELETE: Remove Slot ---
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $status_check = $conn->query("SELECT status FROM parking_slots WHERE id = $id")->fetch_assoc();
    
    if ($status_check['status'] == 'booked') {
        $message = "Operation Denied: Cannot delete a booked slot.";
        $msg_type = "error";
    } else {
        $conn->query("DELETE FROM parking_slots WHERE id = $id");
        $message = "Slot removed from system.";
        $msg_type = "success";
    }
}

include('includes/header.php');

// --- 4. READ: Fetch all slots ---
$slots = $conn->query("SELECT * FROM parking_slots ORDER BY id ASC");
?>

<style>
    :root { --avail: #10b981; --book: #ef4444; --dark: #1e293b; --accent: #3b82f6; }
    .crud-wrapper { padding: 30px; max-width: 1100px; margin: 0 auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    
    .alert { padding: 12px; border-radius: 6px; margin-bottom: 20px; font-weight: 600; text-align: center; }
    .success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
    .error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

    .action-panel { background: #fff; padding: 20px; border-radius: 10px; border: 1px solid #e2e8f0; margin-bottom: 25px; display: flex; gap: 12px; align-items: center; }
    .action-panel input { padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; flex-grow: 1; outline: none; }
    .btn-create { background: var(--accent); color: white; border: none; padding: 10px 25px; border-radius: 6px; cursor: pointer; font-weight: 700; transition: 0.2s; }
    .btn-create:hover { background: #2563eb; }

    .slot-table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .slot-table th { background: #f8fafc; padding: 15px; text-align: left; color: #64748b; font-size: 0.75rem; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
    .slot-table td { padding: 14px 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }

    .badge { padding: 4px 10px; border-radius: 12px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; }
    .badge-available { background: #dcfce7; color: #166534; }
    .badge-booked { background: #fee2e2; color: #991b1b; }

    .crud-link { text-decoration: none; font-size: 0.8rem; font-weight: 700; margin-right: 12px; transition: 0.2s; }
    .link-edit { color: var(--accent); }
    .link-del { color: #dc2626; }
    .crud-link:hover { text-decoration: underline; }
</style>

<div class="crud-wrapper">
    <div style="display:flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 style="margin:0; color: var(--dark);">Slot Inventory Management</h2>
        <span style="color: #94a3b8; font-size: 0.85rem;">Total Slots: <?php echo $slots->num_rows; ?></span>
    </div>

    <?php if($message): ?>
        <div class="alert <?php echo $msg_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" class="action-panel">
        <label style="font-weight: 600; font-size: 0.9rem;">New Slot:</label>
        <input type="text" name="slot_number" placeholder="Enter name (e.g., Zone-A-01)" required>
        <button type="submit" name="add_slot" class="btn-create">Add to System</button>
    </form>

    <table class="slot-table">
        <thead>
            <tr>
                <th>Reference</th>
                <th>Slot Designation</th>
                <th>Current Status</th>
                <th>Last Update</th>
                <th>Admin Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($s = $slots->fetch_assoc()): ?>
            <tr>
                <td style="color: #94a3b8; font-family: monospace;">ID-<?php echo $s['id']; ?></td>
                <td style="font-weight: 700; color: var(--dark);"><?php echo strtoupper($s['slot_number']); ?></td>
                <td>
                    <span class="badge badge-<?php echo $s['status'] ?: 'available'; ?>">
                        <?php echo $s['status'] ?: 'available'; ?>
                    </span>
                </td>
                <td style="font-size: 0.75rem; color: #64748b;">
                    <?php echo date('M d, H:i', strtotime($s['last_updated'])); ?>
                </td>
                <td>
                    <a href="manage_slots.php?toggle_id=<?php echo $s['id']; ?>&current=<?php echo $s['status']; ?>" class="crud-link link-edit">
                        Toggle Status
                    </a>
                    <a href="manage_slots.php?delete_id=<?php echo $s['id']; ?>" class="crud-link link-del" onclick="return confirm('Permanently remove this slot from the system?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>