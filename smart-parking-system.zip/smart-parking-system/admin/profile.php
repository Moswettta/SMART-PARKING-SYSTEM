<?php 
require_once('../includes/db_connect.php'); 
session_start();

// Redirect to login if session is not set (Security)
if(!isset($_SESSION['admin_id'])) {
    // For your project, if you haven't set sessions yet, we'll use ID 1 as a fallback
    $admin_id = 1; 
} else {
    $admin_id = $_SESSION['admin_id'];
}

$msg = "";
$error = "";

// --- 1. ACTION: UPDATE PROFILE ---
if(isset($_POST['update_profile'])) {
    $name = mysqli_real_escape_string($conn, trim($_POST['full_name']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $phone = mysqli_real_escape_string($conn, trim($_POST['phone']));

    if (strlen($name) < 3) {
        $error = "Name must be at least 3 characters.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email.";
    } else {
        $sql = "UPDATE users SET full_name='$name', email='$email', phone='$phone' WHERE id='$admin_id'";
        if($conn->query($sql)) {
            $msg = "Profile updated successfully!";
        } else {
            $error = "Update failed: " . $conn->error;
        }
    }
}

// --- 2. ACTION: UPDATE PASSWORD ---
if(isset($_POST['change_password'])) {
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    if (strlen($new_pass) < 6) {
        $error = "New password must be at least 6 characters.";
    } elseif ($new_pass !== $confirm_pass) {
        $error = "Passwords do not match.";
    } else {
        $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET password='$hashed_pass' WHERE id='$admin_id'";
        if($conn->query($sql)) {
            $msg = "Password changed successfully!";
        }
    }
}

// --- 3. FETCH CURRENT DATA ---
$res = $conn->query("SELECT * FROM users WHERE id='$admin_id'");
$admin = $res->fetch_assoc();

include('includes/header.php'); 
?>

<style>
    /* TRADITIONAL INTERNAL CSS */
    .profile-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
        margin-top: 20px;
    }

    .profile-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    }

    .profile-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .profile-avatar {
        width: 100px;
        height: 100px;
        background: var(--primary-dark);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        margin: 0 auto 15px;
        border: 4px solid var(--accent-green);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-size: 0.85rem;
        font-weight: 600;
        color: #4a5568;
        margin-bottom: 8px;
    }

    .form-group input {
        width: 100%;
        padding: 12px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        font-size: 0.95rem;
        transition: border-color 0.3s;
    }

    .form-group input:focus {
        border-color: var(--accent-green);
        outline: none;
    }

    .btn-update {
        background: var(--primary-dark);
        color: white;
        border: none;
        padding: 12px 25px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        width: 100%;
        transition: opacity 0.3s;
    }

    .btn-update:hover {
        opacity: 0.9;
    }

    .alert {
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 25px;
        font-size: 0.9rem;
    }

    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

    @media (max-width: 768px) {
        .profile-grid { grid-template-columns: 1fr; }
    }
</style>

<div class="container">
    <div class="profile-header">
        <div class="profile-avatar">
            <?php echo strtoupper(substr($admin['full_name'], 0, 1)); ?>
        </div>
        <h2>Account Settings</h2>
        <p style="color: #718096;">Manage your administrative information and security.</p>
    </div>

    <?php if($msg): ?> <div class="alert alert-success"><?php echo $msg; ?></div> <?php endif; ?>
    <?php if($error): ?> <div class="alert alert-danger"><?php echo $error; ?></div> <?php endif; ?>

    <div class="profile-grid">
        <div class="profile-card">
            <h3 style="margin-bottom: 20px; color: var(--primary-dark);">Personal Details</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($admin['full_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($admin['phone']); ?>">
                </div>
                <button type="submit" name="update_profile" class="btn-update">Update Profile</button>
            </form>
        </div>

        <div class="profile-card">
            <h3 style="margin-bottom: 20px; color: var(--primary-dark);">Security</h3>
            <form method="POST">
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="new_password" placeholder="At least 6 characters" required>
                </div>
                <div class="form-group">
                    <label>Confirm New Password</label>
                    <input type="password" name="confirm_password" placeholder="Repeat new password" required>
                </div>
                <button type="submit" name="change_password" class="btn-update" style="background: var(--accent-green);">Change Password</button>
            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>