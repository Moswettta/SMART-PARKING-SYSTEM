<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Handle User Deletion
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    // Prevent admin from deleting themselves
    if ($id == $_SESSION['admin_id']) {
        $error = "You cannot delete your own administrative account.";
    } else {
        $conn->query("DELETE FROM users WHERE id = $id");
        header("Location: view-users.php?success=1");
        exit();
    }
}

include('includes/header.php');

// Fetch Users with their total booking count
$query = "SELECT u.*, COUNT(b.id) as total_bookings 
          FROM users u 
          LEFT JOIN bookings b ON u.id = b.user_id 
          GROUP BY u.id 
          ORDER BY u.created_at DESC";
$users = $conn->query($query);
?>

<style>
    .user-manager { padding: 30px; max-width: 1200px; margin: 0 auto; }
    .user-card { background: white; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    
    .table-head { background: #f8fafc; border-bottom: 2px solid #e2e8f0; }
    .table-head th { padding: 15px; text-align: left; font-size: 0.75rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; }
    
    .user-row td { padding: 15px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
    .user-row:hover { background: #fbfcfe; }

    .role-pill { padding: 4px 10px; border-radius: 50px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; }
    .role-admin { background: #fee2e2; color: #991b1b; }
    .role-user { background: #dcfce7; color: #166534; }

    .avatar { width: 38px; height: 38px; background: #2563eb; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; margin-right: 12px; }
    .btn-action { padding: 6px 12px; border-radius: 6px; font-size: 0.8rem; text-decoration: none; font-weight: 600; }
    .btn-delete { color: #ef4444; border: 1px solid #fee2e2; }
    .btn-delete:hover { background: #fee2e2; }
</style>

<div class="user-manager">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <div>
            <h2 style="margin:0; color: #1e293b;">👥 Registered Users</h2>
            <p style="color: #64748b; font-size: 0.9rem; margin-top: 5px;">Manage hotel guests and administrative staff accounts.</p>
        </div>
        <?php if(isset($error)): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 10px 20px; border-radius: 8px; font-size: 0.85rem;">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>
    </div>

    

    <div class="user-card">
        <table style="width: 100%; border-collapse: collapse;">
            <thead class="table-head">
                <tr>
                    <th>User Identification</th>
                    <th>Role</th>
                    <th>Phone Number</th>
                    <th>Bookings Made</th>
                    <th>Join Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $users->fetch_assoc()): ?>
                <tr class="user-row">
                    <td>
                        <div style="display: flex; align-items: center;">
                            <div class="avatar"><?php echo strtoupper(substr($row['full_name'], 0, 1)); ?></div>
                            <div>
                                <div style="font-weight: 700; color: #1e293b;"><?php echo htmlspecialchars($row['full_name']); ?></div>
                                <div style="font-size: 0.8rem; color: #94a3b8;"><?php echo htmlspecialchars($row['email']); ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="role-pill role-<?php echo $row['role']; ?>">
                            <?php echo $row['role']; ?>
                        </span>
                    </td>
                    <td>
                        <span style="font-family: monospace; font-size: 0.9rem;">
                            <?php echo $row['phone'] ? htmlspecialchars($row['phone']) : '<small style="color:#cbd5e1">No Phone</small>'; ?>
                        </span>
                    </td>
                    <td>
                        <div style="font-weight: 600;">
                            <?php echo $row['total_bookings']; ?> sessions
                        </div>
                    </td>
                    <td style="color: #64748b; font-size: 0.85rem;">
                        <?php echo date('M d, Y', strtotime($row['created_at'])); ?>
                    </td>
                    <td>
                        <?php if($row['id'] != $_SESSION['admin_id']): ?>
                            <a href="view-users.php?delete_id=<?php echo $row['id']; ?>" 
                               class="btn-action btn-delete" 
                               onclick="return confirm('Are you sure you want to delete this user? This will remove all their parking history.')">
                               Delete
                            </a>
                        <?php else: ?>
                            <span style="color: #cbd5e1; font-size: 0.8rem; font-style: italic;">Current Session</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('includes/footer.php'); ?>