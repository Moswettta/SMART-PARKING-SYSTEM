<?php 
session_start();
require_once('../includes/db_connect.php'); 
require_once('../includes/functions.php');

// 1. Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

include('includes/header.php'); 

// 2. Data Aggregation
$slots = $conn->query("SELECT COUNT(*) as total, SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) as avail FROM parking_slots")->fetch_assoc();
$revenue = $conn->query("SELECT SUM(amount) as total FROM payments WHERE payment_status='completed'")->fetch_assoc();
$total_users = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='user'")->fetch_assoc();
$pending_count = $conn->query("SELECT COUNT(*) as total FROM bookings WHERE status='pending'")->fetch_assoc();
?>

<style>
    :root {
        --primary: #1e293b;
        --accent: #3b82f6;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --bg: #f8fafc;
        --white: #ffffff;
    }

    body { font-family: 'Inter', 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 0; }
    .admin-container { padding: 40px; max-width: 1400px; margin: 0 auto; }

    /* Clickable Stats Cards */
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 40px; }
    .stat-card {
        background: var(--white);
        padding: 25px;
        border-radius: 16px;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        border: 1px solid #e2e8f0;
        transition: all 0.2s ease-in-out;
        text-decoration: none;
        display: block;
        cursor: pointer;
    }
    .stat-card:hover { 
        transform: translateY(-5px); 
        border-color: var(--accent);
        box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
    }
    .stat-card h3 { font-size: 0.75rem; color: #64748b; margin: 0; text-transform: uppercase; letter-spacing: 1.2px; font-weight: 700; }
    .stat-card p { font-size: 2rem; font-weight: 800; margin: 12px 0 0; color: var(--primary); }
    .stat-card .footer-link { font-size: 0.75rem; color: var(--accent); margin-top: 10px; display: block; font-weight: 600; }

    /* Layout Grid */
    .dashboard-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
    .data-panel { background: var(--white); padding: 30px; border-radius: 20px; border: 1px solid #e2e8f0; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05); }
    .data-panel h2 { font-size: 1.2rem; margin-top: 0; margin-bottom: 25px; color: var(--primary); display: flex; align-items: center; gap: 10px; }

    /* Table Design */
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; color: #94a3b8; font-size: 0.75rem; padding: 12px 15px; text-transform: uppercase; border-bottom: 1px solid #f1f5f9; }
    td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; color: var(--primary); }
    
    .badge { padding: 5px 10px; border-radius: 6px; font-size: 10px; font-weight: 800; text-transform: uppercase; }
    .badge-pending { background: #fffbeb; color: #b45309; }
    .badge-active { background: #f0fdf4; color: #15803d; }
    .badge-cancelled { background: #fef2f2; color: #991b1b; }
    .badge-completed { background: #f1f5f9; color: #475569; }
    
    /* Action Buttons */
    .action-stack { display: flex; flex-direction: column; gap: 12px; }
    .btn { 
        display: flex; align-items: center; justify-content: center; gap: 10px;
        padding: 14px; border-radius: 10px; text-decoration: none; font-weight: 700; 
        font-size: 0.85rem; transition: 0.3s; 
    }
    .btn-verify { background: var(--success); color: white; }
    .btn-verify:hover { background: #059669; }
    .btn-slots { background: var(--accent); color: white; }
    .btn-logout { background: #f1f5f9; color: var(--danger); margin-top: 20px; }

    .ref-code { font-family: 'Courier New', monospace; font-weight: bold; color: #475569; background: #f1f5f9; padding: 2px 5px; border-radius: 4px; }
</style>

<div class="admin-container">
    <header style="margin-bottom: 40px;">
        <h1 style="font-size: 28px; color: var(--primary); margin: 0;">Hotel Command Center</h1>
        <p style="color: #64748b; margin: 5px 0 0;">System Overview • <?php echo date('l, d F Y'); ?></p>
    </header>

    <div class="stats-row">
        <a href="payments.php" class="stat-card">
            <h3>Revenue (Paid)</h3>
            <p>Ksh <?php echo number_format($revenue['total'] ?? 0); ?></p>
            <span class="footer-link">View Statement →</span>
        </a>
        <a href="verify_payments.php" class="stat-card" style="border-top: 4px solid var(--warning);">
            <h3>Pending Approvals</h3>
            <p style="color: var(--warning);"><?php echo $pending_count['total'] ?? 0; ?></p>
            <span class="footer-link">Process Requests →</span>
        </a>
        <a href="manage_slots.php" class="stat-card">
            <h3>Available Slots</h3>
            <p><?php echo $slots['avail'] ?? 0; ?><span style="font-size: 1rem; color: #cbd5e1;">/<?php echo $slots['total'] ?? 0; ?></span></p>
            <span class="footer-link">Manage Map →</span>
        </a>
        <a href="users.php" class="stat-card">
            <h3>Total Motorists</h3>
            <p><?php echo $total_users['total'] ?? 0; ?></p>
            <span class="footer-link">View Directory →</span>
        </a>
    </div>

    <div class="dashboard-grid">
        <div class="data-panel">
            <h2>📜 Recent Hotel Bookings</h2>
            <table>
                <thead>
                    <tr>
                        <th>Guest & Plate</th>
                        <th>Slot / County</th>
                        <th>Status</th>
                        <th>Ref Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $query = "SELECT b.*, u.full_name, s.slot_number 
                              FROM bookings b 
                              JOIN users u ON b.user_id = u.id 
                              JOIN parking_slots s ON b.slot_id = s.id 
                              ORDER BY b.id DESC LIMIT 6";
                    
                    $recent = $conn->query($query);

                    if (!$recent || $recent->num_rows == 0):
                        echo "<tr><td colspan='4' style='text-align:center; padding:40px; color:#94a3b8;'>No recent activity.</td></tr>";
                    else:
                        while($r = $recent->fetch_assoc()):
                    ?>
                    <tr>
                        <td>
                            <div style="font-weight: 700;"><?php echo htmlspecialchars($r['full_name']); ?></div>
                            <div style="font-size: 11px; color: var(--accent); font-weight: 600;"><?php echo $r['reg_number'] ?: 'N/A'; ?></div>
                        </td>
                        <td>
                            <div>Slot <?php echo $r['slot_number']; ?></div>
                            <div style="font-size: 11px; color: #94a3b8;"><?php echo $r['county']; ?></div>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo strtolower($r['status']); ?>">
                                <?php echo $r['status']; ?>
                            </span>
                        </td>
                        <td>
                            <span class="ref-code"><?php echo $r['reference_no'] ?: '---'; ?></span>
                        </td>
                    </tr>
                    <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>

        <div class="data-panel">
            <h2>⚡ Quick Operations</h2>
            <div class="action-stack">
                <a href="verify_payments.php" class="btn btn-verify">
                    Verify  Payment Requests (<?php echo $pending_count['total']; ?>)
                </a>
                <a href="manage_slots.php" class="btn btn-slots">
                    Parking Slot Configuration
                </a>
                <a href="users.php" class="btn" style="background: #f1f5f9; color: var(--primary);">
                    Motorist Directory
                </a>
                
                <div style="margin-top: 30px; background: #fdf2f2; padding: 20px; border-radius: 12px; border: 1px solid #fee2e2;">
                    <h4 style="margin: 0; color: var(--danger); font-size: 14px;">Security Notice</h4>
                    <p style="font-size: 12px; color: #991b1b; line-height: 1.5; margin: 8px 0 0;">
                        Always cross-reference the **Reference Code** with your financial statements before approving a booking.
                    </p>
                </div>

                <a href="../logout.php" class="btn btn-logout" onclick="return confirm('Exit Admin Panel?')">
                    Secure Logout
                </a>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>