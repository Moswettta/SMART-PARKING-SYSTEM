<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// 1. Capture Time Filters
$view_type = isset($_GET['view_type']) ? $_GET['view_type'] : 'daily';
$selected_date = isset($_GET['report_date']) ? $_GET['report_date'] : date('Y-m-d');
$selected_month = isset($_GET['report_month']) ? $_GET['report_month'] : date('m');
$selected_year = isset($_GET['report_year']) ? $_GET['report_year'] : date('Y');

// 2. Build SQL Conditions based on selection
if ($view_type == 'daily') {
    $date_clause = "DATE(payment_date) = '$selected_date'";
    $log_clause = "DATE(log_time) = '$selected_date'";
    $user_clause = "DATE(created_at) = '$selected_date'";
    $period_label = "Daily Report: " . date('d M, Y', strtotime($selected_date));
} elseif ($view_type == 'yearly') {
    $date_clause = "YEAR(payment_date) = '$selected_year'";
    $log_clause = "YEAR(log_time) = '$selected_year'";
    $user_clause = "YEAR(created_at) = '$selected_year'";
    $period_label = "Yearly Report: " . $selected_year;
} else {
    $date_clause = "MONTH(payment_date) = '$selected_month' AND YEAR(payment_date) = '$selected_year'";
    $log_clause = "MONTH(log_time) = '$selected_month' AND YEAR(log_time) = '$selected_year'";
    $user_clause = "MONTH(created_at) = '$selected_month' AND YEAR(created_at) = '$selected_year'";
    $period_label = "Monthly Report: " . date("F Y", mktime(0, 0, 0, $selected_month, 10, $selected_year));
}

// 3. Fetch Data
$rev_data = $conn->query("SELECT SUM(amount) as total, COUNT(id) as trans FROM payments WHERE $date_clause AND payment_status='completed'")->fetch_assoc();
$user_data = $conn->query("SELECT COUNT(id) as new_users FROM users WHERE $user_clause")->fetch_assoc();
$slot_stats = $conn->query("SELECT status, COUNT(*) as count FROM parking_slots GROUP BY status");

include('includes/header.php');
?>

<style>
    @media print {
        .no-print { display: none !important; }
        .report-wrapper { width: 100%; border: none; margin: 0; padding: 0; }
    }
    .report-wrapper { max-width: 1100px; margin: 20px auto; padding: 20px; font-family: sans-serif; }
    .filter-section { background: #f1f5f9; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #cbd5e1; }
    .stat-row { display: flex; gap: 20px; margin-bottom: 30px; }
    .stat-card { flex: 1; background: #fff; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; text-align: center; }
    .report-table { width: 100%; border-collapse: collapse; background: #fff; margin-bottom: 30px; }
    .report-table th, .report-table td { border: 1px solid #e2e8f0; padding: 12px; text-align: left; font-size: 0.9rem; }
    .report-table th { background: #f8fafc; color: #64748b; text-transform: uppercase; font-size: 0.75rem; }
    .btn { padding: 8px 16px; border-radius: 4px; cursor: pointer; border: none; font-weight: 700; }
    .btn-blue { background: #2563eb; color: #fff; }
</style>

<div class="report-wrapper">
    <div class="filter-section no-print">
        <form method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
            <div>
                <label>View Mode</label><br>
                <select name="view_type" onchange="this.form.submit()" style="padding: 7px;">
                    <option value="daily" <?= ($view_type == 'daily') ? 'selected' : '' ?>>Daily</option>
                    <option value="monthly" <?= ($view_type == 'monthly') ? 'selected' : '' ?>>Monthly</option>
                    <option value="yearly" <?= ($view_type == 'yearly') ? 'selected' : '' ?>>Yearly</option>
                </select>
            </div>

            <?php if($view_type == 'daily'): ?>
                <div>
                    <label>Select Date</label><br>
                    <input type="date" name="report_date" value="<?= $selected_date ?>" style="padding: 5px;">
                </div>
            <?php elseif($view_type == 'monthly'): ?>
                <div>
                    <label>Month</label><br>
                    <select name="report_month" style="padding: 7px;">
                        <?php for($m=1; $m<=12; $m++) echo "<option value='".str_pad($m,2,'0',STR_PAD_LEFT)."' ".($selected_month == $m ? 'selected' : '').">".date('F', mktime(0,0,0,$m,1))."</option>"; ?>
                    </select>
                </div>
            <?php endif; ?>

            <div>
                <label>Year</label><br>
                <select name="report_year" style="padding: 7px;">
                    <option value="2026" selected>2026</option>
                    <option value="2025">2025</option>
                </select>
            </div>

            <button type="submit" class="btn btn-blue">Filter</button>
            <button type="button" class="btn" onclick="window.print()" style="background:#475569; color:#fff;">Print Report</button>
        </form>
    </div>

    <div style="text-align: center; border-bottom: 2px solid #1e293b; padding-bottom: 15px; margin-bottom: 30px;">
        <h2 style="margin:0;">INTERNATIONAL HOTEL SMART PARKING</h2>
        <h3 style="margin:5px 0; color: #475569;"><?= strtoupper($period_label) ?></h3>
    </div>

    <div class="stat-row">
        <div class="stat-card">
            <small>Revenue</small>
            <h3>Ksh <?= number_format($rev_data['total'] ?? 0, 2) ?></h3>
        </div>
        <div class="stat-card">
            <small>New Users</small>
            <h3><?= $user_data['new_users'] ?></h3>
        </div>
        <div class="stat-card">
            <small>Transactions</small>
            <h3><?= $rev_data['trans'] ?></h3>
        </div>
    </div>

    

    <h4>Financial Transactions</h4>
    <table class="report-table">
        <thead>
            <tr>
                <th>Exact Date/Time</th>
                <th>Payment Method</th>
                <th>Ref Number</th>
                <th>Amount (Ksh)</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $pays = $conn->query("SELECT * FROM payments WHERE $date_clause AND payment_status='completed'");
            if($pays->num_rows > 0):
                while($p = $pays->fetch_assoc()): ?>
                <tr>
                    <td><?= date('d-M-Y H:i', strtotime($p['payment_date'])) ?></td>
                    <td><?= $p['payment_method'] ?></td>
                    <td><?= $p['transaction_reference'] ?: 'CASH_REC' ?></td>
                    <td><?= number_format($p['amount'], 2) ?></td>
                </tr>
            <?php endwhile; else: echo "<tr><td colspan='4' align='center'>No transactions found.</td></tr>"; endif; ?>
        </tbody>
    </table>

    <h4>System Activity Logs</h4>
    <table class="report-table">
        <thead>
            <tr>
                <th>Log Time</th>
                <th>Action</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $logs = $conn->query("SELECT * FROM system_logs WHERE $log_clause ORDER BY log_time DESC");
            if($logs && $logs->num_rows > 0):
                while($l = $logs->fetch_assoc()): ?>
                <tr>
                    <td><?= date('H:i:s', strtotime($l['log_time'])) ?></td>
                    <td><strong><?= $l['action'] ?></strong></td>
                    <td><?= $l['details'] ?></td>
                </tr>
            <?php endwhile; else: echo "<tr><td colspan='3' align='center'>No logs for this period.</td></tr>"; endif; ?>
        </tbody>
    </table>

    <div style="margin-top: 50px; border-top: 1px solid #e2e8f0; padding-top: 10px; font-size: 0.8rem; color: #94a3b8;">
        Printed by Admin on: <?= date('d-M-Y H:i:s') ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>