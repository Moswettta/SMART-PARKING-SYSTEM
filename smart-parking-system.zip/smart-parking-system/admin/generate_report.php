<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// Get Report Type (Default to 'finance')
$type = isset($_GET['type']) ? $_GET['type'] : 'finance';
$report_title = ($type == 'finance') ? "Financial Revenue Report" : "Current Slot Occupancy Report";

include('includes/header.php'); 
?>

<style>
    /* Print-Specific Styling */
    @media print {
        .no-print, nav, .sidebar, footer { display: none !important; }
        body { background: white !important; color: black !important; padding: 0; margin: 0; }
        .report-wrapper { border: none !important; box-shadow: none !important; width: 100% !important; max-width: 100% !important; }
        .print-btn-float { display: none; }
    }

    .report-wrapper { 
        max-width: 900px; margin: 40px auto; background: white; 
        padding: 50px; border: 1px solid #e2e8f0; border-radius: 8px; 
    }
    
    .report-header { text-align: center; border-bottom: 3px solid #1e293b; padding-bottom: 20px; margin-bottom: 30px; }
    .report-header h1 { margin: 0; text-transform: uppercase; letter-spacing: 2px; }
    .report-meta { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; color: #64748b; }

    .report-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    .report-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 12px; text-align: left; font-size: 0.8rem; text-transform: uppercase; }
    .report-table td { border: 1px solid #cbd5e1; padding: 10px; font-size: 0.85rem; }

    .summary-box { background: #f1f5f9; padding: 20px; border-radius: 8px; display: flex; justify-content: space-around; font-weight: 700; }
    
    .print-btn-float {
        position: fixed; bottom: 30px; right: 30px; background: #1e293b; color: white;
        padding: 15px 25px; border-radius: 50px; cursor: pointer; border: none; font-weight: 700;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 999;
    }
</style>

<button class="print-btn-float no-print" onclick="window.print()">🖨️ Click to Print Report</button>

<div class="report-wrapper">
    <div class="report-header">
        <h1>SMART PARKING SYSTEM</h1>
        <p style="margin: 5px 0; color: #64748b;">Parking Management System</p>
    </div>

    <div class="report-meta">
        <span><strong>Report Type:</strong> <?php echo $report_title; ?></span>
        <span><strong>Generated:</strong> <?php echo date('d M Y, H:i'); ?></span>
        <span><strong>Admin:</strong> <?php echo $_SESSION['admin_name'] ?? 'System Admin'; ?></span>
    </div>

    <?php if($type == 'finance'): ?>
        <?php 
        $query = "SELECT p.*, b.reg_number FROM payments p 
                  LEFT JOIN bookings b ON p.booking_id = b.id 
                  WHERE p.payment_status = 'completed' ORDER BY p.payment_date DESC";
        $data = $conn->query($query);
        $total = 0;
        ?>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Vehicle Reg</th>
                    <th>Method</th>
                    <th>Reference</th>
                    <th>Amount (Ksh)</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $data->fetch_assoc()): $total += $row['amount']; ?>
                <tr>
                    <td><?php echo date('Y-m-d H:i', strtotime($row['payment_date'])); ?></td>
                    <td><?php echo strtoupper($row['reg_number'] ?: 'N/A'); ?></td>
                    <td><?php echo $row['payment_method']; ?></td>
                    <td style="font-family: monospace;"><?php echo $row['transaction_reference'] ?: 'CASH/DIRECT'; ?></td>
                    <td style="text-align: right;"><?php echo number_format($row['amount'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="summary-box">
            <span>Total Revenue (Completed):</span>
            <span style="font-size: 1.4rem;">Ksh <?php echo number_format($total, 2); ?></span>
        </div>

    <?php else: ?>
        <?php 
        $data = $conn->query("SELECT * FROM parking_slots ORDER BY slot_number ASC");
        $avail = 0; $booked = 0;
        ?>
        <table class="report-table">
            <thead>
                <tr>
                    <th>Slot Number</th>
                    <th>Current Status</th>
                    <th>Last Status Update</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $data->fetch_assoc()): 
                    ($row['status'] == 'available') ? $avail++ : $booked++;
                ?>
                <tr>
                    <td style="font-weight: 700;"><?php echo strtoupper($row['slot_number']); ?></td>
                    <td style="text-transform: capitalize; color: <?php echo ($row['status'] == 'available') ? 'green' : 'red'; ?>;">
                        <?php echo $row['status'] ?: 'Unknown'; ?>
                    </td>
                    <td><?php echo $row['last_updated']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="summary-box">
            <span>Available: <?php echo $avail; ?></span>
            <span>Occupied: <?php echo $booked; ?></span>
            <span>Total Capacity: <?php echo ($avail + $booked); ?></span>
        </div>
    <?php endif; ?>

    <div style="margin-top: 50px; text-align: center; font-size: 0.8rem; color: #94a3b8; border-top: 1px solid #f1f5f9; padding-top: 20px;">
        End of Official Report. All data is fetched from live server records.
    </div>
</div>

<?php include('includes/footer.php'); ?>