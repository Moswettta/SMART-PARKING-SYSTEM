<footer style="text-align: center; padding: 20px; color: #95a5a6; font-size: 0.8rem;">
        &copy; <?php echo date('Y'); ?> Smart Parking Booking System - Admin Portal
    </footer>
</div> </body>
</html>