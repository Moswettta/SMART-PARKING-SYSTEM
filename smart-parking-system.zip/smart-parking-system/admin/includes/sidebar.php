<style>
    .sidebar-brand {
        text-align: center;
        font-size: 1.5rem;
        font-weight: bold;
        color: var(--accent-green);
        margin-bottom: 30px;
    }
    .nav-links {
        list-style: none;
        padding: 0;
    }
    .nav-links li a {
        padding: 15px 25px;
        text-decoration: none;
        color: #bdc3c7;
        display: block;
        transition: 0.3s;
    }
    .nav-links li a:hover {
        background: rgba(255,255,255,0.1);
        color: var(--accent-green);
    }
</style>

<div class="sidebar">
    <div class="sidebar-brand">SmartPark</div>
    <ul class="nav-links">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="manage-slots.php">Parking Slots</a></li>
        <li><a href="payments.php">Payment Logs</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="view-users.php">Motorists</a></li>
    </ul>
</div>