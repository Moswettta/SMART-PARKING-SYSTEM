<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Parking Admin</title>
    <style>
        /* TRADITIONAL INTERNAL CSS */
        :root {
            --primary-dark: #2c3e50;
            --accent-green: #1abc9c;
            --bg-gray: #f4f7f6;
            --white: #ffffff;
            --danger: #e74c3c;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            background-color: var(--bg-gray);
            display: flex;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background-color: var(--primary-dark);
            height: 100vh;
            position: fixed;
            color: white;
            padding-top: 20px;
        }

        /* Main Content Area */
        .content-wrapper {
            margin-left: 250px;
            width: calc(100% - 250px);
            min-height: 100vh;
        }

        /* Top Navigation Bar */
        .top-navbar {
            background-color: var(--white);
            height: 60px;
            padding: 0 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        /* Dropdown Profile Menu */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
        }

        .dropdown:hover .dropdown-content { display: block; }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover { background-color: #f1f1f1; }

        /* Traditional Table Layouts */
        .container { padding: 30px; }
        .data-card {
            background: var(--white);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        th { background-color: #f8f9fa; color: #333; }
    </style>
</head>
<body>
    <?php include('sidebar.php'); ?>
    <div class="content-wrapper">
        <div class="top-navbar">
            <div style="font-weight: bold;"> PARKING ADMIN</div>
            <div class="dropdown">
                <button style="border:none; background:none; cursor:pointer; font-weight:bold;">
                    Administrator &#9662;
                </button>
                <div class="dropdown-content">
                    <a href="profile.php">Profile</a>
                    <a href="settings.php">Settings</a>
                    <a href="../logout.php" style="color:red;">Logout</a>
                </div>
            </div>
        </div>
        <div class="container">