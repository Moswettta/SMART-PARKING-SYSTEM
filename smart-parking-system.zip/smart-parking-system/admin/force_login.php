<?php
session_start();
require_once('../includes/db_connect.php');

$email = 'admin@gmail.com';
$pass = 'admin';
$hash = password_hash($pass, PASSWORD_DEFAULT);

// 1. Ensure the 'role' column exists
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS role ENUM('user', 'admin') DEFAULT 'user'");

// 2. Clear old attempts and insert fresh
$conn->query("DELETE FROM users WHERE email = '$email'");
$sql = "INSERT INTO users (full_name, email, password, role, phone) 
        VALUES ('System Admin', '$email', '$hash', 'admin', '0700000000')";

if ($conn->query($sql)) {
    // 3. SECRETS OF THE SESSION: Manually log you in right now
    $user_id = $conn->insert_id;
    $_SESSION['admin_id'] = $user_id;
    $_SESSION['admin_name'] = 'System Admin';

    echo "<h2>✅ Success! Admin Created.</h2>";
    echo "<p>I have manually started your session.</p>";
    echo "<a href='payments.php' style='padding:10px 20px; background:blue; color:white; text-decoration:none; border-radius:5px;'>GO TO PAYMENTS PAGE</a>";
} else {
    echo "Error: " . $conn->error;
}
?>