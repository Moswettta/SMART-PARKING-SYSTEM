<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// --- CRUD: Delete User ---
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    // Check if user is an admin before deleting to prevent self-lockout
    $check = $conn->query("SELECT role FROM users WHERE id = $id")->fetch_assoc();
    if ($check['role'] == 'admin') {
        $error = "Cannot delete an Administrator.";
    } else {
        $conn->query("DELETE FROM users WHERE id = $id");
        header("Location: users.php?msg=deleted");
        exit();
    }
}

include('includes/header.php');

// --- READ: Fetch Users with their latest Vehicle & County info ---
// We join with bookings to get the most recent vehicle registration used by the user
$query = "SELECT u.*, b.reg_number, b.county, b.booking_time 
          FROM users u 
          LEFT JOIN (
              SELECT user_id, reg_number, county, booking_time
              FROM bookings 
              WHERE id IN (SELECT MAX(id) FROM bookings GROUP BY user_id)
          ) b ON u.id = b.user_id 
          ORDER BY u.created_at DESC";

$users = $conn->query($query);
?>

<style>
    :root { --primary: #1e293b; --accent: #2563eb; --danger: #ef4444; }
    .users-container { padding: 30px; max-width: 1200px; margin: 0 auto; }
    
    .user-table { width: 100%; border-collapse: collapse; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
    .user-table th { background: #f8fafc; padding: 15px; text-align: left; font-size: 0.75rem; color: #64748b; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
    .user-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }

    .avatar-circle { width: 35px; height: 35px; background: #e2e8f0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #475569; margin-right: 12px; }
    
    .v-badge { background: #f1f5f9; padding: 4px 8px; border-radius: 6px; font-family: monospace; font-weight: 700; color: var(--primary); border: 1px solid #e2e8f0; }
    .county-tag { font-size: 0.75rem; color: #64748b; display: block; margin-top: 4px; }
    
    .role-badge { padding: 3px 8px; border-radius: 12px; font-size: 10px; font-weight: 800; text-transform: uppercase; }
    .role-admin { background: #fee2e2; color: #991b1b; }
    .role-user { background: #dcfce7; color: #166534; }

    .btn-del { color: var(--danger); text-decoration: none; font-size: 0.8rem; font-weight: 700; }
    .btn-del:hover { text-decoration: underline; }
</style>

<div class="users-container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <div>
            <h2 style="margin:0;">👤 User Directory</h2>
            <p style="color: #64748b; font-size: 0.9rem; margin-top: 5px;">Managing all registered drivers and their vehicle profiles.</p>
        </div>
        <?php if(isset($error)): ?>
            <span style="color: var(--danger); font-weight: 700;"><?php echo $error; ?></span>
        <?php endif; ?>
    </div>

    

    <table class="user-table">
        <thead>
            <tr>
                <th>User Details</th>
                <th>Role</th>
                <th>Registered Vehicle</th>
                <th>Contact</th>
                <th>Joined Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $users->fetch_assoc()): ?>
            <tr>
                <td>
                    <div style="display: flex; align-items: center;">
                        <div class="avatar-circle"><?php echo strtoupper(substr($row['full_name'], 0, 1)); ?></div>
                        <div>
                            <div style="font-weight: 700; color: var(--primary);"><?php echo $row['full_name']; ?></div>
                            <div style="font-size: 0.75rem; color: #94a3b8;"><?php echo $row['email']; ?></div>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="role-badge role-<?php echo $row['role']; ?>">
                        <?php echo $row['role']; ?>
                    </span>
                </td>
                <td>
                    <?php if($row['reg_number']): ?>
                        <span class="v-badge"><?php echo strtoupper($row['reg_number']); ?></span>
                        <span class="county-tag">📍 <?php echo $row['county']; ?> County</span>
                    <?php else: ?>
                        <span style="color: #cbd5e1; font-style: italic; font-size: 0.8rem;">No vehicle history</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div style="font-size: 0.85rem; font-weight: 600;"><?php echo $row['phone'] ?: 'N/A'; ?></div>
                </td>
                <td style="font-size: 0.8rem; color: #64748b;">
                    <?php echo date('M d, Y', strtotime($row['created_at'])); ?>
                </td>
                <td>
                    <?php if($row['role'] != 'admin'): ?>
                        <a href="users.php?delete_id=<?php echo $row['id']; ?>" class="btn-del" onclick="return confirm('Delete user account and all history?')">Remove</a>
                    <?php else: ?>
                        <span style="color: #cbd5e1; font-size: 0.8rem;">Protected</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include('includes/footer.php'); ?>