<?php 
require_once('../includes/db_connect.php'); 
include('includes/header.php'); 

$msg = "";
$error = "";

// --- 1. ACTION: UPDATE SETTINGS ---
if (isset($_POST['save_settings'])) {
    $price = mysqli_real_escape_string($conn, $_POST['price_per_hour']);

    // Validation: Ensure price is a positive number
    if (!is_numeric($price) || $price < 0) {
        $error = "Please enter a valid numeric price.";
    } else {
        $sql = "UPDATE system_settings SET setting_value = '$price' WHERE setting_key = 'price_per_hour'";
        if ($conn->query($sql)) {
            $msg = "System settings updated successfully!";
        } else {
            $error = "Database Error: Could not update setting.";
        }
    }
}

// --- 2. FETCH CURRENT SETTINGS ---
$settings_res = $conn->query("SELECT * FROM system_settings");
$settings = [];
while($row = $settings_res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<style>
    /* TRADITIONAL INTERNAL CSS */
    .settings-container {
        max-width: 800px;
        margin-top: 20px;
    }

    .settings-card {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        border-top: 4px solid var(--accent-green);
    }

    .form-group {
        margin-bottom: 25px;
        padding-bottom: 20px;
        border-bottom: 1px solid #f0f2f5;
    }

    .form-group:last-child {
        border-bottom: none;
    }

    .form-group label {
        display: block;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 10px;
        font-size: 1rem;
    }

    .form-group p {
        font-size: 0.85rem;
        color: #718096;
        margin-bottom: 15px;
    }

    .input-wrapper {
        display: flex;
        align-items: center;
        max-width: 300px;
    }

    .currency-prefix {
        background: #edf2f7;
        padding: 12px;
        border: 1px solid #e2e8f0;
        border-right: none;
        border-radius: 6px 0 0 6px;
        color: #4a5568;
        font-weight: bold;
    }

    .form-group input {
        flex: 1;
        padding: 12px;
        border: 1px solid #e2e8f0;
        border-radius: 0 6px 6px 0;
        font-size: 1rem;
    }

    .btn-save {
        background: var(--accent-green);
        color: white;
        border: none;
        padding: 15px 30px;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        font-size: 1rem;
        transition: background 0.3s;
    }

    .btn-save:hover {
        background: #16a085;
    }

    .alert {
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 25px;
    }

    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
</style>

<div class="container">
    <h2>System Configuration</h2>
    <p style="color: #718096;">Adjust the global parameters for the Smart Parking application.</p>

    <div class="settings-container">
        <?php if($msg): ?> <div class="alert alert-success"><?php echo $msg; ?></div> <?php endif; ?>
        <?php if($error): ?> <div class="alert alert-danger"><?php echo $error; ?></div> <?php endif; ?>

        <div class="settings-card">
            <form method="POST">
                
                <div class="form-group">
                    <label>Parking Rate (Price Per Hour)</label>
                    <p>This value is used to calculate the total amount for every booking automatically.</p>
                    <div class="input-wrapper">
                        <span class="currency-prefix">Ksh</span>
                        <input type="number" name="price_per_hour" 
                               value="<?php echo htmlspecialchars($settings['price_per_hour'] ?? '50'); ?>" 
                               step="0.01" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>System Maintenance Mode</label>
                    <p>When enabled, motorists will not be able to book new slots.</p>
                    <select disabled style="padding: 10px; border-radius: 5px; background: #f8f9fa; cursor: not-allowed; width: 100%;">
                        <option>Operational (Online)</option>
                    </select>
                </div>

                <div style="text-align: right;">
                    <button type="submit" name="save_settings" class="btn-save">Save All Changes</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>