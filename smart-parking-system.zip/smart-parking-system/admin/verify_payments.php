<?php
session_start();
require_once('../includes/db_connect.php');
require_once('../includes/functions.php');

// Security Check: Admin Only
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

$message = "";

// --- HANDLE VERIFICATION LOGIC ---
if (isset($_POST['verify_now'])) {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
    $slot_id = mysqli_real_escape_string($conn, $_POST['slot_id']);
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $slot_name = mysqli_real_escape_string($conn, $_POST['slot_name']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);

    $conn->begin_transaction();
    try {
        $conn->query("UPDATE bookings SET status = 'active' WHERE id = '$booking_id'");
        $conn->query("UPDATE payments SET payment_status = 'completed' WHERE booking_id = '$booking_id'");
        $conn->query("UPDATE parking_slots SET status = 'occupied' WHERE id = '$slot_id'");

        $notif_msg = "verified: Your payment of Ksh $amount for Slot $slot_name has been approved. Enjoy your parking!";
        $conn->query("INSERT INTO notifications (user_id, message, is_read) VALUES ('$user_id', '$notif_msg', 0)");

        $conn->commit();
        $message = "<div class='alert alert-success'>✅ Payment Verified. Notification sent to guest.</div>";
    } catch (Exception $e) {
        $conn->rollback();
        $message = "<div class='alert alert-danger'>❌ Error: Verification failed.</div>";
    }
}

// --- HANDLE CANCELLATION/REJECTION LOGIC ---
if (isset($_POST['cancel_request'])) {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $slot_name = mysqli_real_escape_string($conn, $_POST['slot_name']);

    $conn->begin_transaction();
    try {
        // 1. Mark booking as cancelled
        $conn->query("UPDATE bookings SET status = 'cancelled' WHERE id = '$booking_id'");
        
        // 2. Mark payment as failed/cancelled
        $conn->query("UPDATE payments SET payment_status = 'failed' WHERE booking_id = '$booking_id'");

        // 3. Notify the user of the rejection
        $notif_msg = "cancelled: Your parking request for Slot $slot_name was declined by admin. Please contact support if this is an error.";
        $conn->query("INSERT INTO notifications (user_id, message, is_read) VALUES ('$user_id', '$notif_msg', 0)");

        $conn->commit();
        $message = "<div class='alert alert-danger'>🚫 Request for Slot $slot_name has been rejected and user notified.</div>";
    } catch (Exception $e) {
        $conn->rollback();
        $message = "<div class='alert alert-danger'>❌ Error: Could not cancel request.</div>";
    }
}

// Fetch pending bookings
$query = "SELECT b.*, p.amount, p.payment_method, u.full_name, u.id as user_id, s.slot_number 
          FROM bookings b 
          JOIN payments p ON b.id = p.booking_id 
          JOIN users u ON b.user_id = u.id 
          JOIN parking_slots s ON b.slot_id = s.id 
          WHERE b.status = 'pending' 
          ORDER BY b.booking_time ASC";

$pending_list = $conn->query($query);

include('includes/header.php');
?>

<style>
    :root { --bg: #f8fafc; --white: #ffffff; --primary: #1e293b; --accent: #3b82f6; --success: #10b981; --danger: #ef4444; --border: #e2e8f0; }
    body { font-family: 'Inter', sans-serif; background: var(--bg); margin: 0; }
    .container { padding: 40px; max-width: 1200px; margin: 0 auto; }
    .page-header { margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
    .verification-card { background: var(--white); border-radius: 12px; border: 1px solid var(--border); box-shadow: 0 1px 3px rgba(0,0,0,0.05); overflow: hidden; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f1f5f9; padding: 15px; text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; }
    td { padding: 20px 15px; border-bottom: 1px solid var(--border); font-size: 14px; }
    
    .btn-verify { background: var(--success); color: white; border: none; padding: 8px 14px; border-radius: 6px; font-weight: 700; cursor: pointer; margin-bottom: 5px; width: 100%; }
    .btn-reject { background: #fff; color: var(--danger); border: 1px solid var(--danger); padding: 8px 14px; border-radius: 6px; font-weight: 600; cursor: pointer; width: 100%; }
    .btn-reject:hover { background: var(--danger); color: white; }

    .ref-box { font-family: monospace; background: #fffbeb; color: #92400e; padding: 4px 8px; border-radius: 4px; font-weight: 700; border: 1px solid #fef3c7; }
    .alert { padding: 15px; border-radius: 8px; margin-bottom: 25px; font-weight: 600; }
    .alert-success { background: #dcfce7; color: #15803d; }
    .alert-danger { background: #fee2e2; color: #b91c1c; }
</style>

<div class="container">
    <div class="page-header">
        <div>
            <h1>Payment Verification</h1>
            <p style="color: #64748b;">Review pending M-Pesa/Bank payments for the International Hotel.</p>
        </div>
        <a href="dashboard.php" style="text-decoration: none; color: var(--accent); font-weight: 600;">← Back</a>
    </div>

    <?php echo $message; ?>

    

    <div class="verification-card">
        <table>
            <thead>
                <tr>
                    <th>Guest Details</th>
                    <th>Slot</th>
                    <th>Ref Number</th>
                    <th>Amount</th>
                    <th style="width: 180px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($pending_list->num_rows > 0): ?>
                    <?php while ($row = $pending_list->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <div style="font-weight: 700;"><?php echo $row['full_name']; ?></div>
                                <div style="font-size: 11px; color: var(--accent);"><?php echo $row['reg_number']; ?></div>
                            </td>
                            <td><strong>Slot <?php echo $row['slot_number']; ?></strong></td>
                            <td>
                                <span class="ref-box"><?php echo $row['reference_no'] ?: 'NO REF'; ?></span><br>
                                <small style="color:#64748b"><?php echo strtoupper($row['payment_method']); ?></small>
                            </td>
                            <td style="font-weight: 800;">Ksh <?php echo number_format($row['amount'], 2); ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                    <input type="hidden" name="slot_name" value="<?php echo $row['slot_number']; ?>">
                                    <input type="hidden" name="slot_id" value="<?php echo $row['slot_id']; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $row['amount']; ?>">
                                    
                                    <button type="submit" name="verify_now" class="btn-verify" onclick="return confirm('Approve this payment?')">Approve</button>
                                    <button type="submit" name="cancel_request" class="btn-reject" onclick="return confirm('Reject this request? This will notify the user.')">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align:center; padding: 60px; color:#94a3b8;">🛡️ No pending payments found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('includes/footer.php'); ?>