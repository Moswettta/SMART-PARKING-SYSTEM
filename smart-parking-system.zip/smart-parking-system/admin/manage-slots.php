<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// 1. CREATE: Add new slot
if (isset($_POST['add_slot'])) {
    $slot_num = mysqli_real_escape_string($conn, $_POST['slot_num']);
    $conn->query("INSERT INTO parking_slots (slot_number, status) VALUES ('$slot_num', 'available')");
    $msg = "Slot $slot_num added successfully!";
}

// 2. DELETE: Remove a slot
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM parking_slots WHERE id = $id");
    header("Location: manage_slots.php?deleted=1");
    exit();
}

// 3. UPDATE: Toggle Status (Handy for maintenance)
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $current = $_GET['status'];
    $new_status = ($current == 'available') ? 'occupied' : 'available';
    $conn->query("UPDATE parking_slots SET status = '$new_status' WHERE id = $id");
    header("Location: manage_slots.php");
    exit();
}

include('includes/header.php');

?>

<div class="main-wrapper">
    <div class="content-body">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <div>
                <h2 style="margin:0;">Parking Slot Management</h2>
                <p style="color: #64748b;">Add, remove, or change the status of parking bays.</p>
            </div>
        </div>

        <?php if(isset($msg)) echo "<div style='padding:10px; background:#d4edda; color:#155724; border-radius:8px; margin-bottom:20px;'>$msg</div>"; ?>

        <div class="card">
            <form class="input-form" method="POST" style="display: flex; gap: 10px; margin-bottom: 30px;">
                <input type="text" name="slot_num" placeholder="Slot Name (e.g. B-10)" required 
                       style="padding: 12px; border: 1px solid #ddd; border-radius: 8px; width: 250px;">
                <button type="submit" name="add_slot" class="btn-submit" 
                        style="background: #2563eb; color:white; border:none; padding:12px 25px; border-radius:8px; cursor:pointer; font-weight:600;">
                    <i class="fas fa-plus"></i> Add Slot
                </button>
            </form>

            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="text-align: left; border-bottom: 2px solid #f1f5f9;">
                        <th style="padding: 15px;">Slot Number</th>
                        <th style="padding: 15px;">Status</th>
                        <th style="padding: 15px;">Last Update</th>
                        <th style="padding: 15px; text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $res = $conn->query("SELECT * FROM parking_slots ORDER BY slot_number ASC");
                    while($row = $res->fetch_assoc()): 
                        $is_avail = ($row['status'] == 'available');
                        $badge_style = $is_avail ? 'background:#dcfce7; color:#166534;' : 'background:#fee2e2; color:#991b1b;';
                    ?>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 15px;"><strong><?php echo $row['slot_number']; ?></strong></td>
                        <td style="padding: 15px;">
                            <span style="padding:5px 10px; border-radius:5px; font-size:0.75rem; font-weight:bold; <?php echo $badge_style; ?>">
                                <?php echo strtoupper($row['status']); ?>
                            </span>
                        </td>
                        <td style="padding: 15px; color: #64748b; font-size: 0.9rem;">
                            <?php echo date('M d, H:i', strtotime($row['last_updated'])); ?>
                        </td>
                        <td style="padding: 15px; text-align: right;">
                            <a href="manage_slots.php?toggle=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>" 
                               style="color: #3498db; text-decoration: none; margin-right: 15px; font-size: 0.85rem;" 
                               title="Toggle Status">
                               <i class="fas fa-sync-alt"></i> Toggle
                            </a>

                            <a href="manage_slots.php?delete=<?php echo $row['id']; ?>" 
                               onclick="return confirm('Are you sure you want to delete this slot?')"
                               style="color: #ef4444; text-decoration: none; font-size: 0.85rem;" 
                               title="Delete Slot">
                               <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php include('includes/footer.php'); ?>