<?php
session_start();
require_once('../includes/db_connect.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit();
}

// 1. Handle Deletion
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM payments WHERE id = $delete_id");
    header("Location: payments.php?msg=deleted");
    exit();
}

// 2. FETCH DATA WITH "FORCE COMPLETE" LOGIC
// This CASE statement checks if payment_status is blank. 
// If it is blank but the booking is 'active', it displays as 'completed'.
$query = "SELECT 
            p.*, 
            COALESCE(p.transaction_reference, b.reference_no) as final_ref,
            COALESCE(NULLIF(p.payment_method, ''), b.payment_method) as final_method,
            b.reg_number, 
            b.booking_status,
            s.slot_number, 
            u.full_name,
            CASE 
                WHEN p.payment_status = 'completed' THEN 'completed'
                WHEN (p.payment_status = '' OR p.payment_status IS NULL) AND b.status = 'active' THEN 'completed'
                ELSE 'pending'
            END as display_status
          FROM payments p
          LEFT JOIN bookings b ON p.booking_id = b.id
          LEFT JOIN parking_slots s ON b.slot_id = s.id
          LEFT JOIN users u ON b.user_id = u.id
          ORDER BY p.payment_date DESC";

$result = $conn->query($query);
include('includes/header.php');
?>

<style>
    .pay-container { padding: 30px; font-family: 'Segoe UI', sans-serif; background: #f1f5f9; }
    .table-card { background: white; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); overflow: hidden; border: 1px solid #e2e8f0; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f8fafc; padding: 18px; text-align: left; font-size: 0.75rem; color: #64748b; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
    td { padding: 18px; border-bottom: 1px solid #f1f5f9; font-size: 0.95rem; }
    
    .status-badge { padding: 6px 14px; border-radius: 50px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; }
    .status-completed { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .status-pending { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
    
    .btn-delete { color: #dc2626; text-decoration: none; font-size: 0.8rem; font-weight: 600; padding: 6px 12px; border: 1px solid #fecaca; border-radius: 6px; }
    .btn-delete:hover { background: #fee2e2; }
</style>

<div class="pay-container">
    <div style="margin-bottom: 25px;">
        <h1 style="color: #1e293b; margin: 0;">Payment Management</h1>
        <p style="color: #64748b;">Total visibility of international hotel transactions.</p>
    </div>

    <div class="table-card">
        <table>
            <thead>
                <tr>
                    <th>Transaction Date</th>
                    <th>Vehicle Details</th>
                    <th>Slot</th>
                    <th>Reference</th>
                    <th>Method</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <div style="font-weight: 700;"><?= date('M d, Y', strtotime($row['payment_date'])) ?></div>
                            <div style="font-size: 0.8rem; color: #94a3b8;"><?= date('h:i A', strtotime($row['payment_date'])) ?></div>
                        </td>
                        <td>
                            <div style="font-weight: 600; color: #0f172a;"><?= $row['reg_number'] ?: 'WALK-IN' ?></div>
                            <div style="font-size: 0.8rem; color: #64748b;"><?= $row['full_name'] ?></div>
                        </td>
                        <td><span style="font-family: monospace; font-weight: 700; color: #2563eb;"><?= strtoupper($row['slot_number']) ?></span></td>
                        <td><code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px;"><?= $row['final_ref'] ?: 'CASH-000' ?></code></td>
                        <td><?= $row['final_method'] ?></td>
                        <td style="font-weight: 800;">Ksh <?= number_format($row['amount'], 2) ?></td>
                        <td>
                            <span class="status-badge status-<?= $row['display_status'] ?>">
                                <?= $row['display_status'] ?>
                            </span>
                        </td>
                        <td>
                            <a href="payments.php?delete_id=<?= $row['id'] ?>" 
                               class="btn-delete" 
                               onclick="return confirm('Confirm permanent deletion of this record?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align:center; padding: 50px; color: #94a3b8;">No payment records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('includes/footer.php'); ?>