<?php
require_once('includes/db_connect.php');
require_once('includes/functions.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 1. EDIT FUNCTION: UPDATE HOURS & PRICE
if (isset($_POST['update_hours'])) {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
    $new_hours = intval($_POST['duration']);
    
    // Get the hourly rate from settings
    $price_res = $conn->query("SELECT setting_value FROM system_settings WHERE setting_key = 'price_per_hour'");
    $rate = $price_res->fetch_assoc()['setting_value'] ?? 50;

    // Fetch original booking time to calculate new expiry
    $check = $conn->query("SELECT booking_time FROM bookings WHERE id = '$booking_id' AND user_id = '$user_id'");
    if ($b = $check->fetch_assoc()) {
        $new_expiry = date("Y-m-d H:i:s", strtotime($b['booking_time'] . " + $new_hours hours"));
        $new_total = $new_hours * $rate;

        $conn->begin_transaction();
        try {
            // Update Duration
            $conn->query("UPDATE bookings SET expiry_time = '$new_expiry' WHERE id = '$booking_id'");
            // Update Price
            $conn->query("UPDATE payments SET amount = '$new_total' WHERE booking_id = '$booking_id'");
            
            $conn->commit();
            header("Location: history.php?msg=updated");
            exit();
        } catch (Exception $e) {
            $conn->rollback();
        }
    }
}

// 2. CANCEL FUNCTION: (Blocked if Payment is Completed)
if (isset($_GET['cancel_id'])) {
    $cancel_id = mysqli_real_escape_string($conn, $_GET['cancel_id']);

    // Check if paid
    $check_pay = $conn->query("SELECT p.payment_status, b.slot_id FROM bookings b 
                               LEFT JOIN payments p ON b.id = p.booking_id 
                               WHERE b.id = '$cancel_id' AND b.user_id = '$user_id'");
    $data = $check_pay->fetch_assoc();

    if ($data && $data['payment_status'] != 'completed') {
        $slot_id = $data['slot_id'];
        $conn->begin_transaction();
        $conn->query("UPDATE bookings SET booking_status = 'cancelled' WHERE id = '$cancel_id'");
        $conn->query("UPDATE parking_slots SET status = 'available' WHERE id = '$slot_id'");
        $conn->commit();
        header("Location: history.php?msg=cancelled");
    } else {
        header("Location: history.php?msg=denied");
    }
    exit();
}

include('includes/header.php');
?>

<style>
    .history-wrapper { display: flex; background: #f4f7f6; min-height: 100vh; }
    .main-content { margin-left: 260px; padding: 40px; width: calc(100% - 260px); }
    .history-card { background: white; border-radius: 20px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
    .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    .data-table th { background: #f8fafc; color: #64748b; font-size: 0.8rem; text-transform: uppercase; padding: 15px; text-align: left; }
    .data-table td { padding: 15px; border-bottom: 1px solid #edf2f7; }
    .btn-action { padding: 6px 12px; border-radius: 6px; font-size: 0.8rem; font-weight: 600; border: none; cursor: pointer; text-decoration: none; }
    .btn-save { background: #3498db; color: white; }
    .btn-cancel { background: #fee2e2; color: #ef4444; }
    .status-active { color: #3b82f6; font-weight: bold; }
</style>

<div class="history-wrapper">
    <?php include('includes/sidebar.php'); ?>
    <div class="main-content">
        <h1>My Bookings</h1>
        
        <div class="history-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Slot</th>
                        <th>Hours (Edit)</th>
                        <th>Total Price</th>
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT b.id, b.booking_time, b.expiry_time, b.booking_status, s.slot_number, p.amount, p.payment_status 
                            FROM bookings b 
                            JOIN parking_slots s ON b.slot_id = s.id 
                            LEFT JOIN payments p ON p.booking_id = b.id 
                            WHERE b.user_id = '$user_id' ORDER BY b.id DESC";
                    $res = $conn->query($sql);
                    while($row = $res->fetch_assoc()):
                        $is_active = ($row['booking_status'] == 'active');
                        $is_paid = ($row['payment_status'] == 'completed');
                        
                        // Calculate duration
                        $d1 = new DateTime($row['booking_time']);
                        $d2 = new DateTime($row['expiry_time']);
                        $hrs = $d1->diff($d2)->h + ($d1->diff($d2)->days * 24);
                    ?>
                    <tr>
                        <td><strong>Slot <?php echo $row['slot_number']; ?></strong></td>
                        <td>
                            <?php if($is_active && !$is_paid): ?>
                                <form method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
                                    <input type="number" name="duration" value="<?php echo $hrs; ?>" min="1" max="24" style="width:45px;">
                                    <button type="submit" name="update_hours" class="btn-action btn-save">Set</button>
                                </form>
                            <?php else: echo $hrs; ?> hrs <?php endif; ?>
                        </td>
                        <td>Ksh <?php echo number_format($row['amount'], 2); ?></td>
                        <td>
                            <span style="color: <?php echo $is_paid ? '#10b981' : '#f59e0b'; ?>;">
                                <?php echo strtoupper($row['payment_status'] ?? 'PENDING'); ?>
                            </span>
                        </td>
                        <td>
                            <?php if($is_active && !$is_paid): ?>
                                <a href="history.php?cancel_id=<?php echo $row['id']; ?>" class="btn-action btn-cancel" onclick="return confirm('Cancel?')">Cancel</a>
                            <?php else: ?>
                                <span style="color:#94a3b8; font-size:0.75rem;">Locked</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>