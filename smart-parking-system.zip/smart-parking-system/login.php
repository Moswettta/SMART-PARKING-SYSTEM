<?php
require_once('includes/db_connect.php');
session_start();
$error = ""; $success = "";
$view = isset($_GET['view']) ? $_GET['view'] : 'login';

// --- REGISTRATION LOGIC ---
if (isset($_POST['register'])) {
    $name  = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']); // Added Phone
    $pass  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    // Check if email already exists
    $check = $conn->query("SELECT id FROM users WHERE email='$email'");
    if($check->num_rows > 0) { 
        $error = "Email already registered!"; 
    } else {
        // MATCHED TO YOUR SQL DUMP: removed 'role', added 'phone'
        $sql = "INSERT INTO users (full_name, email, password, phone) 
                VALUES ('$name', '$email', '$pass', '$phone')";
        
        if($conn->query($sql)) {
            $success = "Account created! You can now login.";
            $view = 'login';
        } else {
            $error = "Registration failed: " . $conn->error;
        }
    }
}

// --- LOGIN LOGIC ---
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass  = $_POST['password'];
    
    $res = $conn->query("SELECT * FROM users WHERE email='$email'");
    if($res->num_rows > 0) {
        $user = $res->fetch_assoc();
        // Verify hashed password
        if(password_verify($pass, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            
            // Log the action in system_logs (matching your table)
            $user_id = $user['id'];
            $conn->query("INSERT INTO system_logs (action, user_id, details) VALUES ('Login', '$user_id', 'User logged in successfully')");
            
            header("Location: dashboard.php");
            exit();
        } else { $error = "Wrong password!"; }
    } else { $error = "User not found!"; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Park | Auth</title>
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; display: flex; height: 100vh; align-items: center; justify-content: center; margin: 0; }
        .auth-box { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); width: 400px; }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #444; font-size: 0.9rem;}
        .input-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 8px; background: #3498db; color: white; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn:hover { opacity: 0.9; }
        .alert { padding: 10px; border-radius: 8px; margin-bottom: 20px; font-size: 0.85rem; border: 1px solid; }
        .alert-danger { background: #fee2e2; color: #b91c1c; border-color: #fca5a5; }
        .alert-success { background: #dcfce7; color: #15803d; border-color: #86efac; }
        h2 { margin-top: 0; color: #2c3e50; text-align: center;}
    </style>
</head>
<body>

<div class="auth-box">
    <?php if($view == 'login'): ?>
        <h2>Login</h2>
        <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <?php if($success) echo "<div class='alert alert-success'>$success</div>"; ?>
        <form method="POST">
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="email@example.com" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" name="login" class="btn">Sign In</button>
        </form>
        <p style="text-align:center; font-size: 0.9rem;">Don't have an account? <a href="login.php?view=register">Register</a></p>

    <?php else: ?>
        <h2>Register</h2>
        <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST">
            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="full_name" placeholder="John Doe" required>
            </div>
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="john@example.com" required>
            </div>
            <div class="input-group">
                <label>Phone Number</label>
                <input type="text" name="phone" placeholder="0712345678" required>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Create a strong password" required>
            </div>
            <button type="submit" name="register" class="btn" style="background: #1abc9c;">Create Account</button>
        </form>
        <p style="text-align:center; font-size: 0.9rem;">Already registered? <a href="login.php?view=login">Login</a></p>
    <?php endif; ?>
</div>

</body>
</html>