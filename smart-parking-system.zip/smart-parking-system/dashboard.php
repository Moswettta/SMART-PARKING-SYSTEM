<?php
session_start();
require_once('includes/db_connect.php');
require_once('includes/functions.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

$price_res = $conn->query("SELECT setting_value FROM system_settings WHERE setting_key = 'price_per_hour'");
$hourly_rate = $price_res->fetch_assoc()['setting_value'] ?? 50;

$total_slots = $conn->query("SELECT COUNT(*) as total FROM parking_slots")->fetch_assoc()['total'];
$available_slots = $conn->query("SELECT COUNT(*) as avail FROM parking_slots WHERE status = 'available'")->fetch_assoc()['avail'];

$recent_bookings = $conn->query("SELECT b.*, s.slot_number 
                                FROM bookings b 
                                JOIN parking_slots s ON b.slot_id = s.id 
                                WHERE b.user_id = '$user_id' 
                                ORDER BY b.id DESC LIMIT 4");

include('includes/header.php');
?>

<style>
    :root {
        --bg-main: #f8fafc;
        --text-dark: #1e293b;
        --text-muted: #64748b;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --white: #ffffff;
    }

    body { font-family: 'Inter', 'Segoe UI', sans-serif; background: var(--bg-main); margin: 0; }
    
    .dashboard-wrapper { display: flex; min-height: 100vh; }
    .main-content { flex: 1; padding: 30px; margin-left: 250px; }

    /* Minimal Stats Cards */
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .stat-card { 
        background: var(--white); 
        padding: 20px; 
        border-radius: 12px; 
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        border: 1px solid #e2e8f0;
    }
    .stat-card h3 { margin: 0; font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
    .stat-card p { margin: 8px 0 0; font-size: 24px; font-weight: 700; color: var(--text-dark); }

    /* Layout Grid */
    .layout-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 30px; }
    .panel { background: var(--white); padding: 25px; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }

    /* Parking Map Grid */
    .parking-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(85px, 1fr)); gap: 12px; margin-top: 20px; }
    .slot-box { 
        text-decoration: none; 
        display: flex; 
        flex-direction: column; 
        align-items: center; 
        padding: 15px 5px; 
        border-radius: 10px; 
        font-weight: 700;
        transition: transform 0.2s, box-shadow 0.2s;
        border: 1.5px solid transparent;
    }
    .slot-box:hover { transform: translateY(-3px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    
    /* Dynamic Colors for Slots */
    .slot-available { background: #ecfdf5; color: var(--success); border-color: #d1fae5; }
    .slot-pending { background: #fffbeb; color: var(--warning); border-color: #fef3c7; }
    .slot-occupied { background: #fef2f2; color: var(--danger); border-color: #fee2e2; }

    .slot-box span.num { font-size: 18px; }
    .slot-box span.lbl { font-size: 9px; text-transform: uppercase; margin-top: 4px; opacity: 0.8; }

    /* Recent Activity List */
    .activity-item { 
        display: flex; 
        justify-content: space-between; 
        padding: 12px 0; 
        border-bottom: 1px solid #f1f5f9; 
    }
    .badge { 
        font-size: 9px; 
        padding: 3px 8px; 
        border-radius: 20px; 
        font-weight: 800; 
        text-transform: uppercase; 
    }
    .badge-pending { background: #fff7ed; color: #c2410c; }
    .badge-active { background: #f0fdf4; color: #15803d; }

    @media (max-width: 992px) {
        .layout-grid { grid-template-columns: 1fr; }
        .main-content { margin-left: 0; }
    }
</style>

<div class="dashboard-wrapper">
    <?php include('includes/sidebar.php'); ?>

    <div class="main-content">
        <header style="margin-bottom: 30px;">
            <h1 style="color: var(--text-dark); margin: 0; font-size: 22px;">Welcome back, <?php echo explode(' ', $user_name)[0]; ?></h1>
            <p style="color: var(--text-muted); font-size: 14px; margin: 5px 0;">Hotel Parking Overview • <?php echo date('l, jS F'); ?></p>
        </header>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Available Slots</h3>
                <p style="color: var(--success);"><?php echo $available_slots; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Capacity</h3>
                <p><?php echo $total_slots; ?></p>
            </div>
            <div class="stat-card">
                <h3>Hourly Rate</h3>
                <p>Ksh <?php echo $hourly_rate; ?></p>
            </div>
        </div>

        <div class="layout-grid">
            <div class="panel">
                <h2 style="font-size: 16px; margin-top: 0; color: var(--text-dark);">📍 Live Parking Map</h2>
                <div class="parking-grid">
                    <?php 
                    $slots = $conn->query("SELECT * FROM parking_slots ORDER BY slot_number ASC");
                    while($s = $slots->fetch_assoc()): 
                        // Logic to check if someone has a pending request
                        $is_pending = $conn->query("SELECT id FROM bookings WHERE slot_id = '".$s['id']."' AND status = 'pending'")->num_rows > 0;
                        
                        $class = "slot-available";
                        $label = "Free";
                        $link = "bookings.php?slot_id=" . $s['id'];

                        if($is_pending) {
                            $class = "slot-pending";
                            $label = "Pending";
                            $link = "#";
                        } elseif($s['status'] != 'available') {
                            $class = "slot-occupied";
                            $label = "Taken";
                            $link = "#";
                        }
                    ?>
                        <a href="<?php echo $link; ?>" class="slot-box <?php echo $class; ?>">
                            <span class="num"><?php echo $s['slot_number']; ?></span>
                            <span class="lbl"><?php echo $label; ?></span>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>

            <div class="panel">
                <h2 style="font-size: 16px; margin-top: 0; color: var(--text-dark);">📜 My Recent History</h2>
                <div style="margin-top: 15px;">
                    <?php if($recent_bookings->num_rows > 0): ?>
                        <?php while($rb = $recent_bookings->fetch_assoc()): ?>
                            <div class="activity-item">
                                <div>
                                    <div style="font-size: 13px; font-weight: 600; color: var(--text-dark);">Slot <?php echo $rb['slot_number']; ?></div>
                                    <div style="font-size: 11px; color: var(--text-muted);"><?php echo $rb['reg_number']; ?></div>
                                </div>
                                <div style="text-align: right;">
                                    <span class="badge badge-<?php echo $rb['status']; ?>"><?php echo $rb['status']; ?></span>
                                    <div style="font-size: 10px; color: #cbd5e1; margin-top: 4px;"><?php echo date('H:i', strtotime($rb['booking_time'])); ?></div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="font-size: 13px; color: var(--text-muted); text-align: center; padding: 20px;">No recent bookings.</p>
                    <?php endif; ?>
                </div>
                <a href="my-history.php" style="display: block; text-align: center; margin-top: 20px; font-size: 12px; color: #3b82f6; text-decoration: none; font-weight: 600;">View Full History →</a>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>