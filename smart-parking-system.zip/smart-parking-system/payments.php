<?php
session_start();
require_once('includes/db_connect.php');
require_once('includes/functions.php');

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Fetch Payment History joined with Bookings for Slot and Plate info
$sql = "SELECT p.*, b.reg_number, b.county, b.reference_no, s.slot_number 
        FROM payments p 
        JOIN bookings b ON p.booking_id = b.id 
        JOIN parking_slots s ON b.slot_id = s.id 
        WHERE b.user_id = '$user_id' 
        ORDER BY p.payment_date DESC";

$payments = $conn->query($sql);

include('includes/header.php');
?>

<style>
    :root {
        --bg-main: #f8fafc;
        --primary: #1e293b;
        --text-muted: #64748b;
        --success: #10b981;
        --warning: #f59e0b;
        --border: #e2e8f0;
    }

    body { font-family: 'Inter', sans-serif; background: var(--bg-main); margin: 0; }
    
    .wrapper { display: flex; min-height: 100vh; }
    .main-content { flex: 1; padding: 40px; margin-left: 250px; }

    /* Header Section */
    .page-header { margin-bottom: 30px; }
    .page-header h1 { font-size: 24px; color: var(--primary); margin: 0; }
    .page-header p { color: var(--text-muted); font-size: 14px; margin-top: 5px; }

    /* Table Styling */
    .table-card {
        background: #ffffff;
        border-radius: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        border: 1px solid var(--border);
        overflow: hidden;
    }

    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { 
        background: #f1f5f9; 
        padding: 15px 20px; 
        font-size: 11px; 
        text-transform: uppercase; 
        letter-spacing: 1px; 
        color: var(--text-muted);
        border-bottom: 1px solid var(--border);
    }
    td { padding: 18px 20px; border-bottom: 1px solid var(--border); font-size: 14px; color: var(--primary); }
    tr:last-child td { border-bottom: none; }

    /* Status Badges */
    .badge {
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
    }
    .badge-paid { background: #dcfce7; color: #15803d; }
    .badge-pending { background: #fffbeb; color: #b45309; }

    /* Typography helpers */
    .ref-code { font-family: 'Courier New', monospace; font-weight: bold; color: #475569; }
    .amount { font-weight: 700; color: var(--primary); }
    .muted-small { font-size: 12px; color: var(--text-muted); }

    @media (max-width: 992px) {
        .main-content { margin-left: 0; padding: 20px; }
    }
</style>

<div class="wrapper">
    <?php include('includes/sidebar.php'); ?>

    <div class="main-content">
        <div class="page-header">
            <h1>Transaction History</h1>
            <p>View and track your hotel parking payments and receipts.</p>
        </div>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Vehicle & Slot</th>
                        <th>Location (County)</th>
                        <th>Payment Method</th>
                        <th>Reference No.</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($payments->num_rows > 0): ?>
                        <?php while($row = $payments->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo date('d M, Y', strtotime($row['payment_date'])); ?></div>
                                    <div class="muted-small"><?php echo date('h:i A', strtotime($row['payment_date'])); ?></div>
                                </td>
                                <td>
                                    <div style="font-weight: 600;"><?php echo $row['reg_number']; ?></div>
                                    <div class="muted-small">Slot: <?php echo $row['slot_number']; ?></div>
                                </td>
                                <td><?php echo $row['county']; ?></td>
                                <td>
                                    <span class="muted-small"><?php echo $row['payment_method']; ?></span>
                                </td>
                                <td>
                                    <span class="ref-code"><?php echo !empty($row['reference_no']) ? $row['reference_no'] : '---'; ?></span>
                                </td>
                                <td class="amount">Ksh <?php echo number_format($row['amount'], 2); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($row['payment_status']); ?>">
                                        <?php echo $row['payment_status']; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 50px; color: var(--text-muted);">
                                No payment records found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="margin-top: 20px; text-align: right;">
            <button onclick="window.print()" style="background: white; border: 1px solid var(--border); padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; color: var(--primary);">
                🖨️ Print Statement
            </button>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>