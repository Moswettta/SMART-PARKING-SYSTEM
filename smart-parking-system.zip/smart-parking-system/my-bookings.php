<?php
session_start();
require_once('includes/db_connect.php');
require_once('includes/functions.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// --- HANDLE CANCELLATION LOGIC ---
if (isset($_POST['cancel_booking'])) {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
    
    // Security: Ensure the booking belongs to the user and is still PENDING
    $check = $conn->query("SELECT id FROM bookings WHERE id = '$booking_id' AND user_id = '$user_id' AND status = 'pending'");
    
    if ($check->num_rows > 0) {
        $conn->query("UPDATE bookings SET status = 'cancelled' WHERE id = '$booking_id'");
        $message = "<div class='alert alert-success'>Booking #$booking_id has been cancelled successfully.</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: Only pending bookings can be cancelled.</div>";
    }
}

// Fetch All Bookings
$sql = "SELECT b.*, s.slot_number 
        FROM bookings b 
        JOIN parking_slots s ON b.slot_id = s.id 
        WHERE b.user_id = '$user_id' 
        ORDER BY b.booking_time DESC";

$result = $conn->query($sql);

include('includes/header.php');
?>

<style>
    :root {
        --primary: #1e293b;
        --bg: #f8fafc;
        --border: #e2e8f0;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --accent: #3b82f6;
    }

    body { font-family: 'Inter', sans-serif; background: var(--bg); margin: 0; }
    .wrapper { display: flex; min-height: 100vh; }
    .main-content { flex: 1; padding: 40px; margin-left: 250px; }

    .header-section { margin-bottom: 30px; }
    .header-section h1 { font-size: 22px; color: var(--primary); margin: 0; }

    .table-container {
        background: white;
        border-radius: 12px;
        border: 1px solid var(--border);
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        overflow: hidden;
    }

    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { background: #f1f5f9; padding: 15px 20px; font-size: 11px; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px; }
    td { padding: 18px 20px; border-bottom: 1px solid var(--border); font-size: 14px; color: var(--primary); }
    
    .badge { padding: 4px 10px; border-radius: 20px; font-size: 10px; font-weight: 700; text-transform: uppercase; }
    .status-pending { background: #fffbeb; color: #b45309; }
    .status-active { background: #f0fdf4; color: #15803d; }
    .status-completed { background: #f1f5f9; color: #475569; }
    .status-cancelled { background: #fef2f2; color: #991b1b; }
    .status-expired { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }

    .btn-print {
        display: inline-block;
        background: var(--accent);
        color: white;
        text-decoration: none;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        transition: 0.2s;
    }
    .btn-print:hover { background: #2563eb; transform: translateY(-1px); }

    .btn-cancel {
        background: white;
        border: 1.5px solid var(--danger);
        color: var(--danger);
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
    }
    .btn-cancel:hover { background: var(--danger); color: white; }

    .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; }
</style>

<div class="wrapper">
    <?php include('includes/sidebar.php'); ?>

    <div class="main-content">
        <div class="header-section">
            <h1>My Reservation History</h1>
            <p style="color: #64748b; margin-top: 5px;">View your tickets and parking status at International Hotel.</p>
        </div>

        <?php echo $message; ?>

        

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Details</th>
                        <th>Location</th>
                        <th>Slot</th>
                        <th>Time & Expiry</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): 
                            // --- EXPIRY LOGIC ---
                            $current_time = time();
                            $expiry_timestamp = strtotime($row['expiry_time']);
                            $is_expired = ($current_time > $expiry_timestamp && $row['status'] != 'cancelled');
                            
                            $display_status = $row['status'];
                            if ($is_expired) { $display_status = 'expired'; }
                        ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 700;"><?php echo $row['reg_number']; ?></div>
                                    <div style="font-size: 11px; color: #94a3b8;">Ref: <?php echo $row['reference_no'] ?: 'N/A'; ?></div>
                                </td>
                                <td><?php echo $row['county']; ?></td>
                                <td><strong style="color: #3b82f6;">Slot <?php echo $row['slot_number']; ?></strong></td>
                                <td>
                                    <div style="font-size: 13px;"><?php echo date('d M, H:i', strtotime($row['booking_time'])); ?></div>
                                    <div style="font-size: 11px; color: <?php echo $is_expired ? '#ef4444' : '#64748b'; ?>;">
                                        Ends: <?php echo date('H:i', $expiry_timestamp); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge status-<?php echo strtolower($display_status); ?>">
                                        <?php echo $display_status; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($display_status == 'active'): ?>
                                        <a href="print_ticket.php?id=<?php echo $row['id']; ?>" target="_blank" class="btn-print">🖨️ Print Ticket</a>
                                    <?php elseif ($display_status == 'pending'): ?>
                                        <form method="POST" onsubmit="return confirm('Stop this booking?');">
                                            <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" name="cancel_booking" class="btn-cancel">Cancel</button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: #cbd5e1; font-size: 12px;">No Actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align: center; padding: 40px; color: #94a3b8;">No bookings found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>