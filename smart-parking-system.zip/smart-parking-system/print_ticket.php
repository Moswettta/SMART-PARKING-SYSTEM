<?php
session_start();
require_once('includes/db_connect.php');

// Security check
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: login.php");
    exit();
}

$booking_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Fetch booking details
$query = "SELECT b.*, s.slot_number, u.full_name 
          FROM bookings b 
          JOIN parking_slots s ON b.slot_id = s.id 
          JOIN users u ON b.user_id = u.id
          WHERE b.id = '$booking_id' AND b.user_id = '$user_id'";

$result = $conn->query($query);
$data = $result->fetch_assoc();

if (!$data) { 
    header("Location: my_bookings.php");
    exit();
}

// Logic for Expiry
$is_expired = (strtotime($data['expiry_time']) < time());

// Generate QR Data string representing the actual ticket info
$qr_content = "INTL HOTEL PARKING\n";
$qr_content .= "ID: " . $data['id'] . "\n";
$qr_content .= "Plate: " . strtoupper($data['reg_number']) . "\n";
$qr_content .= "Slot: " . $data['slot_number'] . "\n";
$qr_content .= "Exp: " . date('d/m/y H:i', strtotime($data['expiry_time']));

$qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=" . urlencode($qr_content);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print Ticket - <?php echo $data['reg_number']; ?></title>
    <style>
        body { font-family: 'Inter', sans-serif; background: #f8fafc; display: flex; flex-direction: column; align-items: center; padding-top: 50px; }
        
        /* Ticket Styling */
        .ticket-box {
            background: #fff;
            width: 380px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            text-align: center;
        }
        .ticket-header { background: #1e293b; color: #fff; padding: 20px; }
        .ticket-body { padding: 30px; }
        
        .qr-frame { 
            padding: 10px; 
            border: 2px dashed #e2e8f0; 
            display: inline-block; 
            margin-bottom: 20px; 
            background: #fff;
        }

        .info-group { margin-bottom: 12px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; display: flex; justify-content: space-between; font-size: 14px; }
        .info-label { color: #64748b; font-weight: 500; }
        .info-value { color: #1e293b; font-weight: 700; }

        /* UI Buttons */
        .controls { margin-bottom: 30px; display: flex; gap: 10px; }
        .btn { padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: 600; text-decoration: none; border: none; font-size: 14px; transition: 0.3s; }
        .btn-print { background: #3b82f6; color: white; }
        .btn-return { background: #fff; color: #475569; border: 1px solid #cbd5e0; }
        .btn:hover { opacity: 0.9; transform: translateY(-1px); }

        .expired-stamp { color: #ef4444; font-weight: 900; border: 3px solid #ef4444; display: inline-block; padding: 5px 15px; transform: rotate(-5deg); margin-top: 10px; }

        @media print {
            .controls { display: none; }
            body { background: white; padding: 0; }
            .ticket-box { box-shadow: none; border: 2px solid #000; width: 100%; }
        }
    </style>
</head>
<body>

<div class="controls">
    <button onclick="window.print()" class="btn btn-print">🖨️ Print Ticket</button>
    <a href="my-bookings.php" class="btn btn-return">← Back to My Bookings</a>
</div>



<div class="ticket-box">
    <div class="ticket-header">
        <h2 style="margin: 0; font-size: 20px;">SCAN ME</h2>
        <p style="margin: 5px 0 0; font-size: 12px; opacity: 0.8;">Smart Parking Pass</p>
    </div>

    <div class="ticket-body">
        <div class="qr-frame">
            <img src="<?php echo $qr_url; ?>" alt="Ticket QR Code">
        </div>

        <div class="info-group">
            <span class="info-label">Guest Name</span>
            <span class="info-value"><?php echo $data['full_name']; ?></span>
        </div>
        <div class="info-group">
            <span class="info-label">Plate Number</span>
            <span class="info-value"><?php echo strtoupper($data['reg_number']); ?></span>
        </div>
        <div class="info-group">
            <span class="info-label">Parking Slot</span>
            <span class="info-value" style="color: #3b82f6;">Slot <?php echo $data['slot_number']; ?></span>
        </div>
        <div class="info-group">
            <span class="info-label">Valid Until</span>
            <span class="info-value"><?php echo date('d M, H:i', strtotime($data['expiry_time'])); ?></span>
        </div>

        <?php if ($is_expired): ?>
            <div class="expired-stamp">EXPIRED</div>
        <?php else: ?>
            <div style="margin-top: 15px; color: #10b981; font-weight: 700; font-size: 12px;">✅ VALID TICKET</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>