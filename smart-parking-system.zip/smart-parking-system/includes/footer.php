</div> <footer style="text-align: center; padding: 20px; color: #7f8c8d; font-size: 0.8rem; margin-left: 250px;">
        &copy; <?php echo date('Y'); ?> Smart Parking System - MKU Project | All Rights Reserved
    </footer>

    <script>
        // Placeholder for any real-time notifications or animations
        console.log("Motorist Portal Loaded");
    </script>
</body>
</html>