<?php
error_reporting(0);
session_start();
include 'includes/db_connect.php'; // make sure your DB connection is included

// Get the current page name for active state styling
$current_page = basename($_SERVER['PHP_SELF']);

// Count unread notifications
$user_id = $_SESSION['user_id'];
$notif_res = $conn->query("SELECT COUNT(*) as unread FROM notifications WHERE user_id = '$user_id' AND is_read = 0");
$unread_count = $notif_res->fetch_assoc()['unread'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart Park</title>

<style>
/* ===== Reset ===== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* ===== Sidebar Container ===== */
.sidebar {
    width: 230px;
    height: 100vh;
    background: #1f2a36;
    color: #ffffff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-family: Arial, sans-serif;
    position: fixed;
    left: 0;
    top: 0;
}

/* ===== Brand ===== */
.sidebar-brand {
    padding: 20px;
    font-size: 18px;
    font-weight: bold;
    border-bottom: 1px solid #2e3c4a;
}

/* ===== Navigation ===== */
.nav-list {
    list-style: none;
}

.nav-item a {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 20px;
    text-decoration: none;
    color: #cfd8dc;
    font-size: 14px;
}

.nav-item a i {
    margin-right: 8px;
}

/* Hover */
.nav-item a:hover {
    background: #2e3c4a;
    color: #ffffff;
}

/* Active Page */
.nav-item.active a {
    background: #34495e;
    color: #ffffff;
}

/* Badge */
.badge {
    background: #e74c3c;
    color: #fff;
    padding: 2px 6px;
    font-size: 11px;
    border-radius: 10px;
    margin-left: 5px;
}

/* Divider */
.sidebar hr {
    margin: 15px 20px;
    border: 0;
    border-top: 1px solid #2e3c4a;
}

/* ===== Footer ===== */
.sidebar-footer {
    padding: 15px 20px;
    border-top: 1px solid #2e3c4a;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 13px;
}

.user-avatar {
    width: 35px;
    height: 35px;
    background: #3498db;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
    .sidebar {
        width: 180px;
    }
}
</style>

</head>
<body>

<div class="sidebar">

    <div>
        <div class="sidebar-brand">
            🅿️ Smart Park
        </div>

        <ul class="nav-list">

            <li class="nav-item <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php">
                    <span><i>🏠</i> Dashboard</span>
                </a>
            </li>

            <li class="nav-item <?php echo ($current_page == 'my-bookings.php' || $current_page == 'booking.php') ? 'active' : ''; ?>">
                <a href="my-bookings.php">
                    <span><i>🎫</i> My Bookings</span>
                </a>
            </li>

            <li class="nav-item <?php echo ($current_page == 'payments.php') ? 'active' : ''; ?>">
                <a href="payments.php">
                    <span><i>💳</i> Payment History</span>
                </a>
            </li>

            <li class="nav-item <?php echo ($current_page == 'notifications.php') ? 'active' : ''; ?>">
                <a href="notifications.php">
                    <span><i>🔔</i> Notifications</span>
                    <?php if($unread_count > 0): ?>
                        <span class="badge"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a>
            </li>

            <li class="nav-item <?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>">
                <a href="profile.php">
                    <span><i>👤</i> Profile Settings</span>
                </a>
            </li>

            <hr>

            <li class="nav-item">
                <a href="logout.php" style="color: #e74c3c;">
                    <span><i>🚪</i> Logout</span>
                </a>
            </li>

        </ul>
    </div>

    <div class="sidebar-footer">
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
            </div>
            <div>
                <div style="font-weight: bold;">
                    <?php echo explode(' ', $_SESSION['user_name'])[0]; ?>
                </div>
                <div style="font-size: 0.7rem; color: #bdc3c7;">
                    Motorist Account
                </div>
            </div>
        </div>
    </div>

</div>

</body>
</html>
