<?php
// Database Configuration
$host     = "localhost";
$username = "root";         // Default for XAMPP
$password = "";             // Default for XAMPP
$dbname   = "smart_parking_db";   // Ensure this matches your database name

// Create Connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    // If connection fails, stop everything and show the error
    die("Connection failed: " . $conn->connect_error);
}

// Set Charset to UTF-8 for special characters (like currency symbols)
$conn->set_charset("utf8mb4");

// Global Timezone (Useful for accurate booking timestamps in Kenya)
date_default_timezone_set('Africa/Nairobi'); 
?>