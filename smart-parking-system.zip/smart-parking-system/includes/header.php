<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Parking | Motorist Portal</title>
</head>
<body style="margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6;">

    <div class="top-nav" style="background-color: #ffffff; height: 70px; display: flex; align-items: center; justify-content: space-between; padding: 0 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 1000;">
        
        <div class="logo-area">
            <h3 style="margin:0; color: #2c3e50; letter-spacing: 1px; font-size: 1.5rem;">
                SMART<span style="color: #3498db;">PARK</span>
            </h3>
        </div>

        <div class="profile-dropdown" onclick="toggleDropdown(event)" style="position: relative; cursor: pointer;">
            <div class="user-trigger" style="display: flex; align-items: center; gap: 12px; padding: 5px 10px; border-radius: 8px; transition: background 0.3s;">
                
                <div class="avatar-circle" style="width: 40px; height: 40px; background-color: #3498db; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem; box-shadow: 0 2px 5px rgba(52, 152, 219, 0.3);">
                    <?php echo isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'M'; ?>
                </div>

                <div style="text-align: left;">
                    <div style="font-size: 0.9rem; font-weight: 700; color: #2c3e50;">
                        <?php echo $_SESSION['user_name'] ?? 'Motorist'; ?>
                    </div>
                    <div style="font-size: 0.75rem; color: #95a5a6;">Active Account</div>
                </div>
                
                <span style="font-size: 0.8rem; color: #bdc3c7; margin-left: 5px;">▼</span>
            </div>

            <div id="userDropdown" class="dropdown-menu" style="position: absolute; right: 0; top: 55px; width: 200px; background: white; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); border: 1px solid #eee; display: none; z-index: 1001;">
                <a href="profile.php" style="display: block; padding: 12px 20px; text-decoration: none; color: #34495e; font-size: 0.9rem; border-bottom: 1px solid #f1f1f1;">👤 My Profile</a>
                <a href="my-history.php" style="display: block; padding: 12px 20px; text-decoration: none; color: #34495e; font-size: 0.9rem; border-bottom: 1px solid #f1f1f1;">📜 Booking History</a>
                <div class="dropdown-divider" style="height: 1px; background: #eee;"></div>
                <a href="logout.php" class="logout-link" style="display: block; padding: 12px 20px; text-decoration: none; color: #e74c3c; font-size: 0.9rem; font-weight: 600;">🚪 Sign Out</a>
            </div>
        </div>
    </div>

    <div class="main-content" style="padding: 40px 30px;">
        </div>

    <script>
        function toggleDropdown(event) {
            event.stopPropagation(); // Prevents the "window click" from instantly closing it
            const menu = document.getElementById('userDropdown');
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
            } else {
                menu.style.display = 'none';
            }
        }

        // Close the menu if user clicks anywhere else on the page
        window.onclick = function(event) {
            const menu = document.getElementById('userDropdown');
            if (menu.style.display === 'block') {
                menu.style.display = 'none';
            }
        }
    </script>

</body>
</html>