<?php
/**
 * Calculates total parking fee
 * @param string $start (Y-m-d H:i:s)
 * @param string $end   (Y-m-d H:i:s)
 * @param float $rate   (Price per hour)
 * @return float
 */
function calculateParkingFee($start, $end, $rate) {
    $time1 = strtotime($start);
    $time2 = strtotime($end);
    $diff_seconds = $time2 - $time1;
    
    // Convert to hours and round up (standard parking logic)
    $hours = ceil($diff_seconds / 3600);
    
    // Minimum 1 hour charge
    if($hours < 1) $hours = 1;
    
    return $hours * $rate;
}

/**
 * Generates a unique string for the QR Code
 */
function generateQRString($booking_id, $user_id) {
    return "SPARK-" . $booking_id . "-" . $user_id . "-" . bin2hex(random_bytes(4));
}
?>