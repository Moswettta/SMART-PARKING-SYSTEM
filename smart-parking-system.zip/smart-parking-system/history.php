<?php
require_once('includes/db_connect.php');
require_once('includes/functions.php');
session_start();

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// 2. THE CANCELLATION ENGINE (Triggered by ?cancel_id=X)
if (isset($_GET['cancel_id'])) {
    $cancel_id = mysqli_real_escape_string($conn, $_GET['cancel_id']);

    // Find the slot_id associated with this specific booking before updating
    $find_sql = "SELECT slot_id FROM bookings WHERE id = '$cancel_id' AND user_id = '$user_id' AND booking_status = 'active'";
    $find_res = $conn->query($find_sql);
    
    if ($find_res && $find_res->num_rows > 0) {
        $booking_row = $find_res->fetch_assoc();
        $target_slot = $booking_row['slot_id'];

        // Start Transaction to ensure data consistency
        $conn->begin_transaction();

        try {
            // A. Revert the Parking Slot to Available
            $conn->query("UPDATE parking_slots SET status = 'available' WHERE id = '$target_slot'");

            // B. Mark the Booking as Cancelled
            $conn->query("UPDATE bookings SET booking_status = 'cancelled' WHERE id = '$cancel_id'");

            // C. Log the activity for the administrator
            $log_details = "User ID $user_id cancelled booking #$cancel_id. Slot #$target_slot is now free.";
            $conn->query("INSERT INTO system_logs (action, user_id, details) VALUES ('Cancellation', '$user_id', '$log_details')");

            $conn->commit();
            $status_msg = "<div style='background:#dcfce7; color:#15803d; padding:15px; border-radius:10px; margin-bottom:20px; border:1px solid #bcf0da;'>✅ Booking #$cancel_id cancelled. Slot $target_slot has been freed.</div>";
        } catch (Exception $e) {
            $conn->rollback();
            $status_msg = "<div style='background:#fee2e2; color:#b91c1c; padding:15px; border-radius:10px; margin-bottom:20px;'>❌ Error: Could not cancel booking.</div>";
        }
    }
}

include('includes/header.php');
?>

<style>
    .history-container { display: flex; background: #f8fafc; min-height: 100vh; }
    .content-area { margin-left: 260px; padding: 40px; width: 100%; }
    .table-card { background: white; border-radius: 15px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); padding: 25px; }
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; padding: 12px; border-bottom: 2px solid #f1f5f9; color: #64748b; font-size: 0.85rem; text-transform: uppercase; }
    td { padding: 15px 12px; border-bottom: 1px solid #f1f5f9; color: #1e293b; }
    .badge { padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
    .badge-active { background: #dbeafe; color: #1e40af; }
    .badge-cancelled { background: #f1f5f9; color: #475569; }
    .btn-cancel { color: #ef4444; text-decoration: none; font-weight: 600; font-size: 0.85rem; border: 1px solid #fee2e2; padding: 5px 10px; border-radius: 6px; }
    .btn-cancel:hover { background: #fef2f2; }
</style>

<div class="history-container">
    <?php include('includes/sidebar.php'); ?>

    <div class="content-area">
        <h1 style="margin-bottom: 10px; color: #0f172a;">My Parking History</h1>
        <p style="color: #64748b; margin-bottom: 30px;">View and manage your current and previous reservations.</p>

        <?php echo $status_msg; ?>

        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Slot</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $list_sql = "SELECT b.*, s.slot_number 
                                 FROM bookings b 
                                 JOIN parking_slots s ON b.slot_id = s.id 
                                 WHERE b.user_id = '$user_id' 
                                 ORDER BY b.booking_time DESC";
                    $result = $conn->query($list_sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $is_active = ($row['booking_status'] == 'active');
                            ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td><strong>Slot <?php echo $row['slot_number']; ?></strong></td>
                                <td><?php echo date('M d, H:i', strtotime($row['booking_time'])); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $row['booking_status']; ?>">
                                        <?php echo strtoupper($row['booking_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($is_active): ?>
                                        <a href="history.php?cancel_id=<?php echo $row['id']; ?>" 
                                           class="btn-cancel" 
                                           onclick="return confirm('Are you sure you want to cancel this booking and free the slot?')">
                                           Cancel Booking
                                        </a>
                                    <?php else: ?>
                                        <span style="color: #94a3b8; font-size: 0.8rem;">No Actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align:center; padding:30px;'>No bookings found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>