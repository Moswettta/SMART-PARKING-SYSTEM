<?php
require_once('includes/db_connect.php');
require_once('includes/functions.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get Price from Settings
$settings_query = "SELECT setting_value FROM system_settings WHERE setting_key = 'price_per_hour' LIMIT 1";
$settings_res = $conn->query($settings_query);
$price_per_hour = ($settings_res->num_rows > 0) ? $settings_res->fetch_assoc()['setting_value'] : 50.00;

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_booking'])) {
    $slot_id = mysqli_real_escape_string($conn, $_POST['slot_id']);
    $reg_number = mysqli_real_escape_string($conn, strtoupper($_POST['reg_number']));
    $county = mysqli_real_escape_string($conn, $_POST['county']);
    $pay_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $ref_no = mysqli_real_escape_string($conn, $_POST['reference_no'] ?? '');
    $hours = (int)$_POST['duration'];
    
    $expiry_time = date('Y-m-d H:i:s', strtotime("+$hours hours"));
    $total_amount = $hours * $price_per_hour;

    // --- DOUBLE BOOKING CHECK ---
    $check_sql = "SELECT id FROM bookings WHERE reg_number = '$reg_number' AND status IN ('pending', 'active')";
    $check_res = $conn->query($check_sql);

    if ($check_res->num_rows > 0) {
        $message = "<div class='alert alert-danger'>Error: This vehicle ($reg_number) already has a pending or active booking!</div>";
    } else {
        $conn->begin_transaction();
        try {
            $sql_book = "INSERT INTO bookings (user_id, slot_id, reg_number, county, payment_method, reference_no, status, expiry_time, booking_status) 
                         VALUES ('$user_id', '$slot_id', '$reg_number', '$county', '$pay_method', '$ref_no', 'pending', '$expiry_time', 'pending')";
            $conn->query($sql_book);
            
            $booking_id = $conn->insert_id;
            $conn->query("INSERT INTO payments (booking_id, amount, payment_method, payment_status) 
                         VALUES ('$booking_id', '$total_amount', '$pay_method', 'pending')");

            $conn->commit();
            $message = "<div class='alert alert-success'>Reservation Sent! Waiting for Admin to verify your payment.</div>";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reserve Parking | International Hotel System</title>
    <style>
        :root {
            --primary: #1a2a6c;
            --secondary: #b21f1f;
            --accent: #fdbb2d;
            --bg: #f8f9fa;
            --text: #2d3436;
        }

        body { font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: var(--bg); margin: 0; color: var(--text); }
        .wrapper { display: flex; min-height: 100vh; }
        
        /* Main Content Styling */
        .content { flex: 1; padding: 40px; margin-left: 250px; } /* Adjust margin if sidebar width differs */
        
        .booking-container {
            max-width: 850px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        h2 { margin-top: 0; color: var(--primary); font-size: 24px; border-bottom: 2px solid #eee; padding-bottom: 15px; }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-top: 20px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
        
        input, select {
            width: 100%;
            padding: 14px;
            border: 1px solid #dfe6e9;
            border-radius: 8px;
            font-size: 16px;
            transition: 0.3s;
            background: #fdfdfd;
        }

        input:focus, select:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 8px rgba(26, 42, 108, 0.1); }

        /* Payment Section */
        .payment-section { background: #f1f2f6; padding: 25px; border-radius: 12px; margin-top: 20px; }
        .ref-box { display: none; margin-top: 20px; animation: slideDown 0.4s ease; }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Summary Box */
        .summary {
            background: var(--primary);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin-top: 30px;
        }
        .summary span { font-size: 14px; opacity: 0.8; }
        .summary h3 { margin: 5px 0 0; font-size: 28px; }

        .btn-submit {
            background: var(--primary);
            color: white;
            border: none;
            padding: 18px;
            width: 100%;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 25px;
            transition: 0.3s;
        }

        .btn-submit:hover { background: #0f1a4a; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }

        .alert { padding: 15px; border-radius: 8px; margin-bottom: 25px; font-weight: 500; }
        .alert-success { background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .alert-danger { background: #f8d7da; color: #721c24; border-left: 5px solid #dc3545; }
    </style>
</head>
<body>

<div class="wrapper">
    <?php include('includes/sidebar.php'); ?>

    <div class="content">
        <?php include('includes/header.php'); ?>

        <div class="booking-container">
            <h2>🅿️ Reserve Your Parking Space</h2>
            
            <?php echo $message; ?>

            <form method="POST" id="parkingForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Vehicle Plate Number</label>
                        <input type="text" name="reg_number" placeholder="KAA 123X" required>
                    </div>
                    <div class="form-group">
                        <label>Your County</label>
                        <select name="county" required>
                            <option value="Nairobi">Nairobi</option>
                            <option value="Mombasa">Mombasa</option>
                            <option value="Kiambu">Kiambu</option>
                            <option value="Nakuru">Nakuru</option>
                            <option value="Kisumu">Kisumu</option>
                        </select>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>Available Slot</label>
                        <select name="slot_id" required>
                            <option value="">-- Select a Space --</option>
                            <?php
                            $slots = $conn->query("SELECT * FROM parking_slots WHERE status = 'available'");
                            while($s = $slots->fetch_assoc()) echo "<option value='".$s['id']."'>Slot ".$s['slot_number']."</option>";
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Duration (Hours)</label>
                        <input type="number" name="duration" id="duration" value="1" min="1" max="24">
                    </div>
                </div>

                <div class="payment-section">
                    <label>Preferred Payment Method</label>
                    <select name="payment_method" id="payMethod" onchange="checkPayment()" required>
                        <option value="Cash">Cash at Reception</option>
                        <option value="M-Pesa">M-Pesa Express</option>
                        <option value="Bank">Bank Transfer</option>
                    </select>

                    <div id="referenceArea" class="ref-box">
                        <label id="refLabel">Transaction Reference</label>
                        <input type="text" name="reference_no" id="refInput" placeholder="Enter Code">
                    </div>
                </div>

                <div class="summary">
                    <span>Estimated Total Amount</span>
                    <h3>Ksh <span id="total_cost"><?php echo number_format($price_per_hour, 2); ?></span></h3>
                </div>

                <button type="submit" name="confirm_booking" class="btn-submit">Confirm Reservation Request</button>
            </form>
        </div>
    </div>
</div>

<script>
    const rate = <?php echo $price_per_hour; ?>;
    
    // Live Price Calculation
    document.getElementById('duration').addEventListener('input', function() {
        let val = this.value || 0;
        document.getElementById('total_cost').innerText = (val * rate).toFixed(2);
    });

    // Reference Number Logic
    function checkPayment() {
        const method = document.getElementById('payMethod').value;
        const refArea = document.getElementById('referenceArea');
        const refInput = document.getElementById('refInput');
        const refLabel = document.getElementById('refLabel');

        if (method === 'M-Pesa' || method === 'Bank') {
            refArea.style.display = 'block';
            refInput.required = true;
            refLabel.innerText = method + " Transaction Code";
            refInput.placeholder = method === 'M-Pesa' ? "e.g. RCL9W1S2XG" : "e.g. EFT-990221";
        } else {
            refArea.style.display = 'none';
            refInput.required = false;
            refInput.value = "";
        }
    }
</script>

</body>
</html>