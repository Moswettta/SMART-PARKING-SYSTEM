<?php
require_once('includes/db_connect.php');
session_start();

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = "";
$error = "";

// 2. Handle Profile Update
if (isset($_POST['update_profile'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $sql = "UPDATE users SET full_name='$full_name', phone='$phone', email='$email' WHERE id='$user_id'";
    
    if ($conn->query($sql)) {
        $_SESSION['user_name'] = $full_name; // Update session name for the header
        $success = "Profile updated successfully!";
    } else {
        $error = "Update failed: " . $conn->error;
    }
}

// 3. Fetch Current User Data
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

include('includes/header.php');
?>

<div class="profile-wrapper" style="background-color: #f4f7f6; min-height: 100vh; font-family: 'Segoe UI', Roboto, sans-serif;">
    <?php include('includes/sidebar.php'); ?>

    <main class="main-content" style="margin-left: 250px; padding: 40px; box-sizing: border-box;">
        
        <div style="margin-bottom: 30px;">
            <h1 style="margin:0; color: #0f172a; font-size: 1.8rem; font-weight: 700;">Profile Settings</h1>
            <p style="color: #64748b; margin-top: 5px; font-size: 1rem;">Manage your account details and contact info.</p>
        </div>

        <div class="profile-card" style="
            background: #ffffff; 
            max-width: 650px; 
            padding: 35px; 
            border-radius: 16px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.04);
        ">
            
            <?php if($success): ?>
                <div style="padding: 15px; background-color: #ecfdf5; color: #059669; border-radius: 8px; margin-bottom: 25px; border: 1px solid #d1fae5; font-size: 0.9rem; font-weight: 600;">
                    ✅ <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div style="padding: 15px; background-color: #fef2f2; color: #dc2626; border-radius: 8px; margin-bottom: 25px; border: 1px solid #fee2e2; font-size: 0.9rem; font-weight: 600;">
                    ❌ <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #334155; font-size: 0.85rem;">Full Name</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required style="
                        width: 100%; padding: 12px 15px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; outline: none; transition: border-color 0.2s;
                    " onfocus="this.style.borderColor='#3498db'">
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #334155; font-size: 0.85rem;">Email Address</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required style="
                        width: 100%; padding: 12px 15px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; outline: none;
                    " onfocus="this.style.borderColor='#3498db'">
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #334155; font-size: 0.85rem;">Phone Number (M-Pesa Notifications)</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" placeholder="07XXXXXXXX" required style="
                        width: 100%; padding: 12px 15px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; outline: none;
                    " onfocus="this.style.borderColor='#3498db'">
                </div>

                <div style="margin-bottom: 30px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #334155; font-size: 0.85rem;">Member Since</label>
                    <input type="text" value="<?php echo date('F j, Y', strtotime($user['created_at'])); ?>" readonly style="
                        width: 100%; padding: 12px 15px; border: 1px solid #f1f5f9; background: #f8fafc; color: #94a3b8; border-radius: 8px; font-size: 0.95rem; cursor: not-allowed;
                    ">
                </div>
                
                <button type="submit" name="update_profile" style="
                    width: 100%; 
                    background-color: #3498db; 
                    color: white; 
                    padding: 14px; 
                    border: none; 
                    border-radius: 8px; 
                    font-size: 1rem; 
                    font-weight: 700; 
                    cursor: pointer; 
                    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.25);
                    transition: background 0.2s;
                " onmouseover="this.style.backgroundColor='#2980b9'" onmouseout="this.style.backgroundColor='#3498db'">
                    Update Profile
                </button>
            </form>
        </div>
    </main>
</div>

<?php include('includes/footer.php'); ?>