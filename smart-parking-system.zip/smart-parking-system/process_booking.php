<?php
require_once('includes/db_connect.php');
session_start();

// --- DEBUGGING START ---
// If you get redirected, it means one of these is empty.
if (!isset($_SESSION['user_id'])) {
    die("Error: Session expired. Please log in again.");
}

if (!isset($_POST['slot_id']) || empty($_POST['slot_id'])) {
    // If this triggers, your booking.php form isn't sending the ID correctly
    header("Location: dashboard.php?msg=missing_slot_id");
    exit();
}
// --- DEBUGGING END ---

$user_id = $_SESSION['user_id'];
$slot_id = mysqli_real_escape_string($conn, $_POST['slot_id']);
// Use 'duration' or 'hours' depending on what your booking.php input name is
$hours   = isset($_POST['hours']) ? (int)$_POST['hours'] : (isset($_POST['duration']) ? (int)$_POST['duration'] : 1);

// 1. Fetch Rate
$rate_res = $conn->query("SELECT setting_value FROM system_settings WHERE setting_key = 'price_per_hour'");
$hourly_rate = $rate_res->fetch_assoc()['setting_value'] ?? 50;
$total_amount = $hours * $hourly_rate;

// 2. Calculate Expiry
$expiry_time = date('Y-m-d H:i:s', strtotime("+$hours hours"));

// 3. Database Transaction
$conn->begin_transaction();

try {
    // A. Create Booking
    $qr_data = "PK-" . $user_id . "-" . time();
    $sql_booking = "INSERT INTO bookings (user_id, slot_id, expiry_time, qr_code_data, booking_status) 
                    VALUES ('$user_id', '$slot_id', '$expiry_time', '$qr_data', 'active')";
    $conn->query($sql_booking);
    $booking_id = $conn->insert_id;

    // B. Update Slot
    $conn->query("UPDATE parking_slots SET status = 'booked' WHERE id = '$slot_id'");

    // C. Create Payment Record
    $sql_payment = "INSERT INTO payments (booking_id, amount, payment_method, payment_status) 
                    VALUES ('$booking_id', '$total_amount', 'M-Pesa', 'pending')";
    $conn->query($sql_payment);

    $conn->commit();

    // SUCCESS: Go to Ticket
    header("Location: view-qr.php?booking_id=" . $booking_id);
    exit();

} catch (Exception $e) {
    $conn->rollback();
    die("Transaction Failed: " . $e->getMessage());
}
?>