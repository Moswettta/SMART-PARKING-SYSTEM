<?php
session_start();
require_once('includes/db_connect.php');
require_once('includes/functions.php');

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch Booking History with Slot Numbers
$sql = "SELECT b.*, s.slot_number 
        FROM bookings b 
        JOIN parking_slots s ON b.slot_id = s.id 
        WHERE b.user_id = '$user_id' 
        ORDER BY b.booking_time DESC";

$history = $conn->query($sql);

include('includes/header.php');
?>

<style>
    :root {
        --bg: #f8fafc;
        --dark: #1e293b;
        --muted: #64748b;
        --border: #e2e8f0;
        --success: #10b981;
        --warning: #f59e0b;
        --info: #3b82f6;
    }

    body { font-family: 'Inter', sans-serif; background: var(--bg); margin: 0; }
    .wrapper { display: flex; min-height: 100vh; }
    .main-content { flex: 1; padding: 40px; margin-left: 250px; }

    .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
    .header-flex h1 { font-size: 22px; color: var(--dark); margin: 0; }

    /* History Cards */
    .history-card {
        background: #fff;
        border-radius: 12px;
        border: 1px solid var(--border);
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        overflow: hidden;
    }

    table { width: 100%; border-collapse: collapse; }
    th { 
        background: #f1f5f9; 
        text-align: left; 
        padding: 15px 20px; 
        font-size: 11px; 
        text-transform: uppercase; 
        color: var(--muted); 
        letter-spacing: 0.5px;
    }
    td { padding: 18px 20px; border-bottom: 1px solid var(--border); font-size: 14px; color: var(--dark); }
    
    /* Status Badges */
    .status-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
    }
    .status-pending { background: #fffbeb; color: #b45309; }
    .status-active { background: #f0fdf4; color: #15803d; }
    .status-completed { background: #f1f5f9; color: #475569; }

    .btn-new {
        background: var(--dark);
        color: white;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.2s;
    }
    .btn-new:hover { background: #334155; }

    .plate-text { font-family: 'Monaco', 'Consolas', monospace; font-weight: bold; color: #0f172a; }
</style>

<div class="wrapper">
    <?php include('includes/sidebar.php'); ?>

    <div class="main-content">
        <div class="header-flex">
            <div>
                <h1>My Parking History</h1>
                <p style="color: var(--muted); font-size: 14px; margin: 5px 0;">Track all your past and present hotel parking sessions.</p>
            </div>
            <a href="new_booking.php" class="btn-new">+ New Reservation</a>
        </div>

        <div class="history-card">
            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Vehicle Details</th>
                        <th>Location (County)</th>
                        <th>Slot</th>
                        <th>Time Period</th>
                        <th>Approval Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($history && $history->num_rows > 0): ?>
                        <?php while($row = $history->fetch_assoc()): 
                            $status_class = "status-" . strtolower($row['status']);
                        ?>
                            <tr>
                                <td style="color: var(--muted);">#PK-<?php echo $row['id']; ?></td>
                                <td>
                                    <span class="plate-text"><?php echo $row['reg_number']; ?></span>
                                </td>
                                <td><?php echo $row['county']; ?></td>
                                <td><strong>Slot <?php echo $row['slot_number']; ?></strong></td>
                                <td>
                                    <div style="font-size: 13px; font-weight: 600;">
                                        <?php echo date('d M, Y', strtotime($row['booking_time'])); ?>
                                    </div>
                                    <div style="font-size: 11px; color: var(--muted);">
                                        Expires: <?php echo date('h:i A', strtotime($row['expiry_time'])); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $status_class; ?>">
                                        <?php echo strtoupper($row['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 60px; color: var(--muted);">
                                <div style="font-size: 40px; margin-bottom: 10px;">🚗</div>
                                <p>No parking records found. Start by making your first reservation!</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>